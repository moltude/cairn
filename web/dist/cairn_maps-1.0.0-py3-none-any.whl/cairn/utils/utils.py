# Web engine: imported by web/bridge.py and run in the browser via Pyodide.
# Keep it free of terminal/UI imports (tests/test_web_engine_surface.py).
"""
Utility functions for Cairn: chunking, HTML stripping, sorting, and file helpers.

This module provides helper functions for handling OnX import limits,
cleaning data, natural sorting, and managing file operations.
"""

from __future__ import annotations

from typing import List, Iterator, Any, Tuple
import re
from pathlib import Path


def natural_sort_key(text: str) -> list[str | int]:
    """
    Generate a sort key for natural/human sorting.

    Natural sorting handles mixed alphanumeric strings correctly,
    sorting "Item 2" before "Item 10" (unlike lexicographic sorting).

    Handles:
    - Zero-padded numbers: 01, 02, ... 10, 11
    - Non-padded numbers: 1, 2, 3, ... 10, 11
    - Alphabetical: A, B, C, ... Z
    - Mixed: "Section 2", "Section 10"

    Args:
        text: The string to generate a sort key for

    Returns:
        A list of string and integer parts for comparison

    Examples:
        >>> natural_sort_key("Item 2")
        ['item ', 2, '']
        >>> natural_sort_key("Item 10")
        ['item ', 10, '']
        >>> sorted(["Item 10", "Item 2", "Item 1"], key=natural_sort_key)
        ['Item 1', 'Item 2', 'Item 10']
        >>> sorted(["02 - B", "01 - A", "10 - C"], key=natural_sort_key)
        ['01 - A', '02 - B', '10 - C']
    """
    if not text:
        return [""]

    def convert(part: str) -> str | int:
        """Convert numeric strings to int, lowercase text otherwise."""
        return int(part) if part.isdigit() else part.lower()

    # Split on digit boundaries, keeping the digits
    # e.g., "Item 10" -> ['Item ', '10', '']
    parts = re.split(r"(\d+)", text)

    return [convert(part) for part in parts]


def chunk_data(items: List[Any], limit: int = 2500) -> Iterator[List[Any]]:
    """
    Split a list into chunks to respect OnX import limits.

    OnX Backcountry crashes with >3000 items, so we use a conservative
    limit of 2500 by default.

    Args:
        items: List of items to chunk
        limit: Maximum items per chunk (default: 2500)

    Yields:
        Lists of items, each with at most 'limit' items

    Example:
        >>> data = list(range(5000))
        >>> chunks = list(chunk_data(data, limit=2500))
        >>> len(chunks)
        2
        >>> len(chunks[0])
        2500
        >>> len(chunks[1])
        2500
    """
    for i in range(0, len(items), limit):
        yield items[i : i + limit]


# A feature property marking its notes as PLAIN TEXT (onX notes, or text the
# user already saw/edited in Cairn), so no HTML stripping is applied: a note may
# legitimately contain "<desc>" or "<Lake>" as text.
PLAIN_NOTES_KEY = "cairn_plain_notes"


def clean_notes(text: str, plain: bool = False) -> str:
    """Notes for display/export: HTML-stripped for HTML-capable sources (CalTopo),
    verbatim (line endings normalized, outer whitespace trimmed) for plain text."""
    if not plain:
        return strip_html(text)
    return (text or "").replace("\r\n", "\n").replace("\r", "\n").strip()


def strip_html(text: str) -> str:
    """
    Remove HTML tags from text.

    CalTopo exports often contain HTML formatting in descriptions,
    but OnX Backcountry expects plain text.

    Args:
        text: Text potentially containing HTML tags

    Line breaks (<br>, </p>, </div>, </li>, CR/LF) are preserved as "\\n"; at most
    one blank line is kept. Use single_line() for names/titles.

    Returns:
        Plain text with HTML tags removed

    Example:
        >>> strip_html("<b>Camp</b> at <i>lake</i>")
        'Camp at lake'
    """
    if not text:
        return ""

    # Normalize line endings, then turn block-level breaks into newlines
    # BEFORE tags are stripped so multi-line notes keep their line breaks.
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"<br\s*/?>|</(?:p|div|li)\s*>", "\n", text, flags=re.IGNORECASE)

    # Remove HTML tags -- only things that look like a real tag: "<" (or "</")
    # immediately followed by a letter, and no "<" inside. A bare "<[^>]+>"
    # also ate plain-text notes such as "< 2 mi from the TH ... > the rest" or
    # "Bring <2L water>", which onX and CalTopo notes contain as ordinary text.
    text = re.sub(r"</?[A-Za-z][A-Za-z0-9:-]*(?:\s[^<>]*)?/?>", "", text)

    # Decode common HTML entities
    html_entities = {
        "&nbsp;": " ",
        "&amp;": "&",
        "&lt;": "<",
        "&gt;": ">",
        "&quot;": '"',
        "&#39;": "'",
        "&apos;": "'",
    }

    for entity, char in html_entities.items():
        text = text.replace(entity, char)

    # Collapse spaces/tabs within each line, trim each line, allow at most one
    # blank line between paragraphs.
    text = "\n".join(re.sub(r"[^\S\n]+", " ", ln).strip() for ln in text.split("\n"))
    text = re.sub(r"\n{3,}", "\n\n", text).strip()

    return text


def single_line(text: str) -> str:
    """Collapse all whitespace (including newlines) to single spaces. For names/titles."""
    return re.sub(r"\s+", " ", text or "").strip()


def sanitize_name_for_onx(name: str) -> Tuple[str, bool]:
    """
    Sanitize waypoint/track names by removing problematic non-alphanumeric characters
    that can cause OnX sorting issues, while preserving natural sort order.

    Removes characters: ! @ # $ % ^ * &
    Preserves: spaces, hyphens, underscores, colons, alphanumeric characters

    Args:
        name: Original waypoint/track name

    Returns:
        Tuple of (sanitized_name, was_changed)
        - sanitized_name: Name with problematic characters removed
        - was_changed: True if any characters were removed, False otherwise

    Examples:
        >>> sanitize_name_for_onx("#01 Porcupine Mile 6.1")
        ('01 Porcupine Mile 6.1', True)
        >>> sanitize_name_for_OnX("#03 & #05 Cow Camp")
        ('03  05 Cow Camp', True)
        >>> sanitize_name_for_OnX("Deadfall")
        ('Deadfall', False)
        >>> sanitize_name_for_OnX("CONICAL PASS CUTOFF 12:45 AM")
        ('CONICAL PASS CUTOFF 12:45 AM', False)
    """
    if not name:
        return name, False

    original = name
    # Characters to remove: ! @ # $ % ^ * &
    # Also remove other problematic symbols but keep spaces, hyphens, underscores
    # Pattern: remove everything that's not alphanumeric, space, hyphen, underscore, colon
    # Note: We keep colon for time formats like "12:45 AM"

    # Remove specific problematic characters that cause sorting issues
    problematic_chars = r"[!@#$%^*&]"
    sanitized = re.sub(problematic_chars, "", name)

    # Clean up multiple spaces that might result from removals
    sanitized = re.sub(r"\s+", " ", sanitized).strip()

    # If name became empty, return original
    if not sanitized:
        return original, False

    was_changed = sanitized != original
    return sanitized, was_changed


def sanitize_filename(name: str) -> str:
    """
    Clean a string to be safe for use as a filename.

    Removes or replaces characters that are problematic in filenames
    across different operating systems.

    Args:
        name: The original name/title

    Returns:
        A filesystem-safe filename

    Example:
        >>> sanitize_filename("Lost Horse Canyon / Trail")
        'Lost_Horse_Canyon_Trail'
    """
    if not name:
        return "Untitled"

    # Replace problematic characters with underscores
    name = re.sub(r'[<>:"/\\|?*]', "_", name)

    # Replace spaces with underscores
    name = name.replace(" ", "_")

    # Remove multiple consecutive underscores
    name = re.sub(r"_+", "_", name)

    # Remove leading/trailing underscores
    name = name.strip("_")

    # Limit length (255 is common filesystem limit, leave room for extensions)
    if len(name) > 200:
        name = name[:200]

    return name or "Untitled"


def estimate_file_size(content: str) -> int:
    """
    Estimate the file size in bytes for a string content.

    Args:
        content: The file content as a string

    Returns:
        Estimated size in bytes
    """
    return len(content.encode("utf-8"))


def format_file_size(size_bytes: int) -> str:
    """
    Format a file size in bytes to a human-readable string.

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted string (e.g., "2.4 MB", "156 KB")
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.1f} MB"


def ensure_output_dir(output_path: Path) -> Path:
    """
    Ensure the output directory exists, creating it if necessary.

    Args:
        output_path: Path to the output directory

    Returns:
        The resolved absolute path
    """
    output_path = Path(output_path).resolve()
    output_path.mkdir(parents=True, exist_ok=True)
    return output_path


def get_geometry_type_name(geometry_type: str) -> str:
    """
    Get a friendly name for a GeoJSON geometry type.

    Args:
        geometry_type: GeoJSON geometry type (e.g., "Point", "LineString")

    Returns:
        Friendly name (e.g., "Waypoint", "Track")
    """
    type_map = {
        "Point": "Waypoint",
        "LineString": "Track",
        "Polygon": "Shape",
        "MultiPoint": "Waypoints",
        "MultiLineString": "Tracks",
        "MultiPolygon": "Shapes",
    }
    return type_map.get(geometry_type, geometry_type)


def should_split(
    item_count: int,
    estimated_size: int,
    max_items: int = 3000,
    max_size: int = 4 * 1024 * 1024,
) -> bool:
    """
    Determine if a dataset should be split based on OnX limits.

    Args:
        item_count: Number of items in the dataset
        estimated_size: Estimated file size in bytes
        max_items: Maximum items allowed (default: 3000)
        max_size: Maximum file size in bytes (default: 4MB)

    Returns:
        True if the dataset exceeds limits and should be split
    """
    return item_count > max_items or estimated_size > max_size
