# Web engine: imported by web/bridge.py and run in the browser via Pyodide.
# Keep it free of terminal/UI imports (tests/test_web_engine_surface.py).
"""
GPX and KML file writers for OnX Backcountry format.

This module generates valid GPX 1.1 files with OnX custom namespace extensions
for waypoints and tracks, and KML 2.2 files for shapes (polygons).
"""

from __future__ import annotations

from typing import List, Optional
import xml.etree.ElementTree as ET
from pathlib import Path
import uuid
import logging
from datetime import datetime, timezone
import math
import re

from cairn.core.parser import ParsedFeature
from xml.sax.saxutils import escape as _sax_escape

# XML 1.0 forbids C0 controls other than tab/LF/CR, U+FFFE/U+FFFF and lone
# surrogates; one of them anywhere makes the whole file unparseable. Names and
# notes can carry them (a pasted control character, a bulk edit), so every text
# the writers emit drops them first. Everything XML allows passes unchanged.
# A translate table, not a regex: the set is listed outright, so no character
# range can be wider than meant (CodeQL py/overly-large-range, 2026-10-25).
_XML_INVALID = dict.fromkeys(
    [c for c in range(0x20) if c not in (0x09, 0x0A, 0x0D)]   # C0 controls but tab, LF, CR
    + [0xFFFE, 0xFFFF]
    + list(range(0xD800, 0xE000))                             # surrogates: only lone ones occur in a str
)


def xml_safe(text: str) -> str:
    """text without the characters XML 1.0 forbids."""
    return text.translate(_XML_INVALID)


def xml_text(text: str) -> str:
    """text made safe for XML character data: forbidden characters dropped, then escaped."""
    return _sax_escape(xml_safe(text))
from cairn.core.mapper import map_icon
from cairn.utils.utils import PLAIN_NOTES_KEY, clean_notes, strip_html, natural_sort_key, sanitize_name_for_onx
from cairn.core.config import IconMappingConfig, resolve_waypoint_color
from cairn.core.color_mapper import (
    AREA_FILL_KEY,
    AREA_STYLE_KEY,
    AREA_WEIGHT_KEY,
    LINE_STYLE_KEY,
    LINE_WEIGHT_KEY,
    ONX_LINE_STYLES,
    ONX_LINE_WEIGHTS,
    ColorMapper,
    pattern_to_style,
    stroke_width_to_weight,
)

# Register the OnX namespace (note: 4 'w's is required)
# IMPORTANT: OnX exports use **lowercase prefix** `onx:` and lowercase domain in the namespace URI.
# While XML namespace prefixes are technically arbitrary, OnX import appears to be prefix-sensitive.
ET.register_namespace("onx", "https://wwww.onxmaps.com/")

# Set up logger for debug output
logger = logging.getLogger(__name__)


# region agent log
def _agent_ndjson_log(payload: dict) -> None:
    """
    Debug-mode NDJSON logger (append-only).

    Disabled unless CAIRN_DEBUG_LOG is set; writes one JSON object per line
    to that path. Best-effort — never raises.
    """
    try:
        import json, os  # noqa: E401

        payload = dict(payload or {})
        # Convert Python timestamp (seconds) to JavaScript timestamp (milliseconds)
        payload.setdefault(
            "timestamp", int(datetime.now(timezone.utc).timestamp() * 1000)
        )
        payload.setdefault("sessionId", "debug-session")
        payload.setdefault("runId", os.environ.get("CAIRN_RUN_ID", "pre-fix"))
        # Opt-in only. Previously this wrote to a hardcoded author-specific path,
        # which meant it was a silent no-op everywhere else; defaulting to a path
        # that exists would have switched unbounded logging on for every user.
        # Set CAIRN_DEBUG_LOG to a file path to enable.
        log_path = os.environ.get("CAIRN_DEBUG_LOG")
        if not log_path:
            return

        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        pass


# endregion

# OnX import max GPX size is 4MB. Use a slightly lower default to avoid edge cases.
DEFAULT_MAX_GPX_BYTES = int(math.floor(3.75 * 1024 * 1024))


def _finite_number(v) -> bool:
    return (
        isinstance(v, (int, float))
        and not isinstance(v, bool)
        and math.isfinite(float(v))
    )


def _trkpt_children(coord) -> List[str]:
    """<ele> and <time> lines for one track point [lon, lat, ele?, epoch_ms?].

    ele is written when present and numeric (None means "no elevation", never 0).
    The time slot is epoch milliseconds, as in CalTopo GeoJSON and the onX GPX
    reader; 0 is CalTopo's "no time", so only a positive value is written. GPX
    wants ele before time.
    """
    out: List[str] = []
    if len(coord) > 2 and _finite_number(coord[2]):
        out.append(f"        <ele>{coord[2]}</ele>")
    if len(coord) > 3 and _finite_number(coord[3]) and coord[3] > 0:
        try:
            ts = datetime.fromtimestamp(coord[3] / 1000, tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            ts = None
        if ts is not None:
            out.append(
                f"        <time>{ts.strftime('%Y-%m-%dT%H:%M:%S')}.{ts.microsecond // 1000:03d}Z</time>"
            )
    return out


def _desc_text(notes_clean: str, kv_lines: List[str], debug_desc: bool) -> str:
    """
    Content for a GPX <desc> element.

    Default: only the user's own notes — <desc> is the field onX shows people,
    so machine state (id/color/icon/...) does not belong there. Color/icon/style
    already travel in the <onx:*> extension elements.

    Debug mode (--debug): the legacy key=value block, kept verbatim for
    troubleshooting.

    Returns "" when there is nothing to write; callers then omit <desc> entirely
    (<desc> is optional in GPX 1.1, and onX imports files without it).
    """
    if debug_desc:
        return "\n".join(kv_lines)
    return (notes_clean or "").strip()

# Global change tracker for name sanitization
# Format: {feature_type: [(original_name, sanitized_name), ...]}
#
# Names now pass through unchanged (utils.sanitize_name_for_onx is an identity;
# onX verified 2026-10-22, DECISIONS.md ENG-06), so these stay empty and the
# RUNBOOK "Renamed for onX" section no longer appears. The tracker is kept as the
# one place a future, genuinely needed rename would be reported.
_name_changes: dict[str, list[tuple[str, str]]] = {
    "waypoints": [],
    "tracks": [],
    "shapes": [],
}


def get_name_changes() -> dict[str, list[tuple[str, str]]]:
    """Get all tracked name changes."""
    return {k: list(v) for k, v in _name_changes.items()}


def clear_name_changes() -> None:
    """Clear tracked name changes (call before processing new folder)."""
    for k in _name_changes:
        _name_changes[k] = []


def track_name_change(feature_type: str, original: str, sanitized: str) -> None:
    """Track a name change for reporting."""
    if original != sanitized:
        _name_changes[feature_type].append((original, sanitized))


def verify_gpx_waypoint_order(gpx_path: Path, max_items: int = 20) -> List[str]:
    """
    Read back waypoint order from a GPX file to verify it matches expected order.

    Args:
        gpx_path: Path to the GPX file to read
        max_items: Maximum number of waypoint names to return (for logging)

    Returns:
        List of waypoint names in the order they appear in the GPX file
    """
    try:
        tree = ET.parse(gpx_path)
        root = tree.getroot()

        # Handle namespace
        ns = {"gpx": "http://www.topografix.com/GPX/1/1"}

        waypoint_names = []
        for wpt in root.findall(".//gpx:wpt", ns):
            name_elem = wpt.find("gpx:name", ns)
            if name_elem is not None and name_elem.text:
                waypoint_names.append(name_elem.text)

        return waypoint_names[:max_items] if max_items else waypoint_names
    except Exception as e:
        logger.warning(f"Could not verify GPX order: {e}")
        return []


def log_waypoint_order(
    features: List[ParsedFeature], label: str = "Waypoint order", max_items: int = 20
) -> None:
    """
    Log the order of waypoints for debugging purposes.

    Args:
        features: List of waypoint features
        label: Label for the log message
        max_items: Maximum number of items to log
    """
    if not logger.isEnabledFor(logging.DEBUG):
        return

    waypoint_names = [f.title for f in features[:max_items]]

    logger.debug(f"[DEBUG] {label}:")
    for i, name in enumerate(waypoint_names, 1):
        logger.debug(f"  {i}. {name}")

    if len(features) > max_items:
        logger.debug(f"  ... and {len(features) - max_items} more waypoints")


def format_waypoint_name(
    original_name: str,
    icon_type: str,
    *,
    use_prefix: bool,
    default_icon: str = "Location",
) -> str:
    """
    Format waypoint name with optional icon prefix based on config,
    and sanitize for OnX sorting compatibility.

    Args:
        original_name: Original name from CalTopo
        icon_type: Mapped icon type (e.g., "Parking", "Caution", "Waypoint")

    Returns:
        Formatted and sanitized name
    """
    if use_prefix and icon_type != default_icon:
        # Add icon type prefix for non-default icons
        name_with_prefix = f"{icon_type} - {original_name}"
    else:
        name_with_prefix = original_name

    # Sanitize name for OnX sorting compatibility
    sanitized_name, was_changed = sanitize_name_for_onx(name_with_prefix)

    # Track changes for reporting
    if was_changed:
        track_name_change("waypoints", name_with_prefix, sanitized_name)

    return sanitized_name


def prettify_xml(elem: ET.Element) -> str:
    """
    Return a pretty-printed XML string for the Element.

    Args:
        elem: XML Element to prettify

    Returns:
        Formatted XML string
    """
    # ET.indent formats in place; minidom.parseString + toprettyxml built a
    # second full DOM, which cost ~2x the time and ~10x the peak memory on a
    # 10k-feature export (0.44s/35MB -> 0.21s/3.3MB, measured). Output is
    # identical to the old minidom result for every element that has children,
    # including the declaration's `?>` spacing and the trailing newline. The one
    # divergence is a childless element: ET renders `<tag />`, minidom `<tag/>`.
    # Semantically the same XML, and unreachable here — real KML output contains
    # no self-closing tags. All of this is pinned in test_writers_prettify.py.
    ET.indent(elem, space="  ")
    body = ET.tostring(elem, encoding="unicode")
    return f'<?xml version="1.0" ?>\n{body}\n'


def _utf8_joined_size(lines: List[str]) -> int:
    """
    Compute the exact UTF-8 byte size of '\\n'.join(lines) (no trailing newline).
    """
    if not lines:
        return 0
    total = 0
    for s in lines:
        total += len((s or "").encode("utf-8"))
    # newline between each adjacent pair
    total += len(lines) - 1
    return total


def _split_gpx_lines_by_bytes(
    *,
    header_lines: List[str],
    item_blocks: List[List[str]],
    footer_line: str,
    max_bytes: int,
) -> List[List[str]]:
    """
    Split a GPX payload represented as header + item blocks + footer into parts
    that are each <= max_bytes when joined with '\\n'.join(...), preserving order.
    """
    footer_bytes = len((footer_line or "").encode("utf-8"))
    header_size = _utf8_joined_size(header_lines)

    parts: List[List[str]] = []
    cur_lines: List[str] = list(header_lines)
    cur_size = header_size  # bytes of '\\n'.join(cur_lines)
    cur_items = 0

    def finalize_current() -> None:
        nonlocal cur_lines, cur_size, cur_items
        if not cur_lines:
            cur_lines = list(header_lines)
            cur_size = header_size
        cur_lines.append(footer_line)
        parts.append(cur_lines)
        cur_lines = list(header_lines)
        cur_size = header_size
        cur_items = 0

    def total_size_if_add_block(block: List[str]) -> int:
        """
        Compute total file size if we add block lines to current body.
        """
        block_size = _utf8_joined_size(block)
        # size of joined body lines after appending block (includes newline between body and block)
        new_body_size = cur_size + (1 if cur_lines else 0) + block_size
        # add newline between body and footer, then footer bytes
        return new_body_size + 1 + footer_bytes

    # If header+footer already exceeds max, we still write at least one part.
    header_footer_total = header_size + (1 if header_lines else 0) + footer_bytes
    if header_footer_total > max_bytes:
        logger.warning(
            f"GPX header/footer alone exceeds max_bytes={max_bytes} ({header_footer_total} bytes). "
            f"Proceeding anyway."
        )

    for block in item_blocks:
        if not block:
            continue

        candidate_total = total_size_if_add_block(block)

        # If adding would exceed and we already have at least one item, finalize and start a new part.
        if candidate_total > max_bytes and cur_items > 0:
            finalize_current()
            candidate_total = total_size_if_add_block(block)

        # If even a single-item part exceeds max, accept it and warn.
        if candidate_total > max_bytes and cur_items == 0:
            logger.warning(
                f"A single GPX item exceeds max_bytes={max_bytes} ({candidate_total} bytes). "
                f"Writing it as a single-part file anyway."
            )

        # Append block to current body and update size.
        if cur_lines:
            cur_size += 1  # newline between existing body and block
        cur_size += _utf8_joined_size(block)
        cur_lines.extend(block)
        cur_items += 1

    # If we added any items (or even if none), finalize one output.
    if cur_items > 0 or not parts:
        finalize_current()

    return parts


def _write_gpx_parts(
    *,
    parts: List[List[str]],
    output_path: Path,
) -> List[tuple[Path, int]]:
    """
    Write one or more GPX parts to disk.
    Returns list of (path, size_bytes).
    """
    written: List[tuple[Path, int]] = []
    if len(parts) == 1:
        output_path.write_text("\n".join(parts[0]), encoding="utf-8")
        written.append((output_path, output_path.stat().st_size))
        return written

    for i, lines in enumerate(parts, 1):
        part_path = output_path.with_name(f"{output_path.stem}_{i}{output_path.suffix}")
        part_path.write_text("\n".join(lines), encoding="utf-8")
        written.append((part_path, part_path.stat().st_size))
    return written


def write_gpx_waypoints_maybe_split(
    features: List[ParsedFeature],
    output_path: Path,
    folder_name: str,
    *,
    sort: bool = True,
    add_timestamps: bool = False,
    config: Optional[IconMappingConfig] = None,
    split: bool = True,
    max_bytes: int = DEFAULT_MAX_GPX_BYTES,
    debug_desc: bool = False,
) -> List[tuple[Path, int, int]]:
    """
    Write waypoints to GPX, automatically splitting into multiple files if the output
    would exceed max_bytes. Preserves order.

    debug_desc: if True, <desc> carries the legacy key=value troubleshooting block;
    by default <desc> contains only the user's own notes (omitted entirely when empty).

    Returns list of (path, size_bytes, written_waypoint_count) for manifest.
    """
    # Keep existing behavior: optional sort.
    if sort:
        features = sorted(features, key=lambda f: natural_sort_key(f.title))

    escape = xml_text

    header_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<gpx xmlns="http://www.topografix.com/GPX/1/1" xmlns:onx="https://wwww.onxmaps.com/" version="1.1" creator="Cairn - CalTopo to OnX Migration Tool">',
        "  <metadata>",
        f"    <name>{escape(folder_name)}</name>",
        "  </metadata>",
    ]
    footer_line = "</gpx>"

    # region agent log
    _agent_ndjson_log(
        {
            "hypothesisId": "A",
            "location": "cairn/core/writers.py:write_gpx_waypoints_maybe_split",
            "message": "Waypoints GPX header namespace",
            "data": {
                "output_path": str(output_path),
                "folder_name": folder_name,
                "header_gpx_line": header_lines[1],
                "registered_ns_uri": "https://wwww.onxmaps.com/",
            },
        }
    )
    # endregion

    item_blocks: List[List[str]] = []
    written_count = 0
    for feature in features:
        if not feature.coordinates or len(feature.coordinates) < 2:
            continue

        lat, lon = feature.coordinates[1], feature.coordinates[0]

        # Map the icon (respect user config if provided), with optional per-feature override.
        mapped_icon = None
        try:
            if isinstance(getattr(feature, "properties", None), dict):
                mapped_icon = (
                    feature.properties.get("cairn_onx_icon_override") or ""
                ).strip() or None
        except Exception:
            mapped_icon = None
        if not mapped_icon:
            mapped_icon = map_icon(
                feature.title, feature.description or "", feature.symbol, config
            )

        # Format the name (optional icon prefix + sanitization)
        formatted_name = format_waypoint_name(
            feature.title,
            mapped_icon,
            use_prefix=bool(getattr(config, "use_icon_name_prefix", False)),
            default_icon=(
                getattr(config, "default_icon", "Location") if config else "Location"
            ),
        )
        formatted_name = escape(formatted_name)

        # Waypoint color: an explicit per-feature override (set by web/bridge.py
        # to exactly the color its UI showed) wins; otherwise the shared rule in
        # config.resolve_waypoint_color (source color, else icon color, else
        # default). The override is still quantized, so a non-palette value
        # cannot reach <onx:color>.
        color_override = ""
        if isinstance(getattr(feature, "properties", None), dict):
            color_override = str(
                feature.properties.get("cairn_onx_color_override") or ""
            ).strip()
        if color_override:
            onx_color = ColorMapper.map_waypoint_color(color_override)
        else:
            onx_color = resolve_waypoint_color(
                feature.color,
                mapped_icon,
                default=(
                    config.default_color
                    if config
                    else ColorMapper.DEFAULT_WAYPOINT_COLOR
                ),
            )

        # region agent log
        if written_count < 3:
            _agent_ndjson_log(
                {
                    "hypothesisId": "B",
                    "location": "cairn/core/writers.py:write_gpx_waypoints_maybe_split",
                    "message": "Waypoint style mapping prior to write",
                    "data": {
                        "idx": written_count,
                        "title": feature.title,
                        "symbol": getattr(feature, "symbol", None),
                        "feature_color_raw": getattr(feature, "color", None),
                        "mapped_icon": mapped_icon,
                        "onx_color": onx_color,
                        "used_feature_color": bool(feature.color),
                        "extensions_tag_sample": "<onx:icon>/<onx:color>",
                    },
                }
            )
        # endregion

        wp_id = (getattr(feature, "id", "") or "").strip() or str(uuid.uuid4())
        notes_clean = clean_notes(feature.description or "", bool(feature.properties.get(PLAIN_NOTES_KEY)))
        desc_content = _desc_text(
            notes_clean,
            [
                f"name={feature.title}",
                f"notes={notes_clean}",
                f"id={wp_id}",
                f"color={onx_color}",
                f"icon={mapped_icon}",
            ],
            debug_desc,
        )

        block: List[str] = []
        block.append(f'  <wpt lat="{lat}" lon="{lon}">')
        block.append(f"    <name>{formatted_name}</name>")
        if add_timestamps:
            timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            block.append(f"    <time>{timestamp}</time>")
        if desc_content:
            # Real newlines are written inside <desc>; whether onX keeps them is UNVERIFIED (see TODO.md).
            block.append(f"    <desc>{escape(desc_content)}</desc>")
        block.append("    <extensions>")
        # The icon can be any text an input file carried (an onX icon
        # outside the catalogue is kept as is), so it is escaped like the name.
        block.append(f"      <onx:icon>{escape(mapped_icon)}</onx:icon>")
        block.append(f"      <onx:color>{onx_color}</onx:color>")
        block.append("    </extensions>")
        block.append("  </wpt>")

        # region agent log
        if written_count < 2:
            _agent_ndjson_log(
                {
                    "hypothesisId": "D",
                    "location": "cairn/core/writers.py:write_gpx_waypoints_maybe_split",
                    "message": "Waypoint extensions exact lines (prefix + order)",
                    "data": {
                        "title": feature.title,
                        "extensions_lines": [
                            f"<onx:icon>{mapped_icon}</onx:icon>",
                            f"<onx:color>{onx_color}</onx:color>",
                        ],
                        "xmlns_decl": header_lines[1],
                    },
                }
            )
        # endregion

        item_blocks.append(block)
        written_count += 1

    # If splitting disabled, keep legacy single-file behavior
    if not split:
        payload = (
            header_lines + [ln for blk in item_blocks for ln in blk] + [footer_line]
        )
        output_path.write_text("\n".join(payload), encoding="utf-8")
        # region agent log
        _agent_ndjson_log(
            {
                "hypothesisId": "E",
                "location": "cairn/core/writers.py:write_gpx_waypoints_maybe_split",
                "message": "Waypoints GPX written (no split)",
                "data": {
                    "output_path": str(output_path),
                    "size_bytes": int(output_path.stat().st_size),
                    "written_count": written_count,
                },
            }
        )
        # endregion
        return [(output_path, output_path.stat().st_size, written_count)]

    # First check: would a single file exceed threshold?
    full_payload = (
        header_lines + [ln for blk in item_blocks for ln in blk] + [footer_line]
    )
    if _utf8_joined_size(full_payload) <= max_bytes:
        output_path.write_text("\n".join(full_payload), encoding="utf-8")
        # region agent log
        _agent_ndjson_log(
            {
                "hypothesisId": "E",
                "location": "cairn/core/writers.py:write_gpx_waypoints_maybe_split",
                "message": "Waypoints GPX written (single part)",
                "data": {
                    "output_path": str(output_path),
                    "size_bytes": int(output_path.stat().st_size),
                    "written_count": written_count,
                    "max_bytes": int(max_bytes),
                },
            }
        )
        # endregion
        return [(output_path, output_path.stat().st_size, written_count)]

    parts = _split_gpx_lines_by_bytes(
        header_lines=header_lines,
        item_blocks=item_blocks,
        footer_line=footer_line,
        max_bytes=max_bytes,
    )
    written = _write_gpx_parts(parts=parts, output_path=output_path)

    # Distribute counts across parts based on item_blocks packing.
    # We approximate by re-parsing: count <wpt> occurrences per part.
    out: List[tuple[Path, int, int]] = []
    for pth, sz in written:
        try:
            txt = pth.read_text(encoding="utf-8")
            cnt = txt.count("<wpt ")
        except Exception:
            cnt = 0
        out.append((pth, sz, cnt))
    # region agent log
    _agent_ndjson_log(
        {
            "hypothesisId": "E",
            "location": "cairn/core/writers.py:write_gpx_waypoints_maybe_split",
            "message": "Waypoints GPX written (split parts)",
            "data": {
                "base_output_path": str(output_path),
                "parts": [
                    {"path": str(p), "size_bytes": int(s), "wpt_count": int(c)}
                    for (p, s, c) in out
                ],
                "total_written_count": written_count,
                "max_bytes": int(max_bytes),
            },
        }
    )
    # endregion
    return out


def write_gpx_tracks_maybe_split(
    features: List[ParsedFeature],
    output_path: Path,
    folder_name: str,
    *,
    sort: bool = True,
    split: bool = True,
    max_bytes: int = DEFAULT_MAX_GPX_BYTES,
    debug_desc: bool = False,
) -> List[tuple[Path, int, int]]:
    """
    Write tracks to GPX, automatically splitting into multiple files if the output
    would exceed max_bytes. Preserves order.

    debug_desc: if True, <desc> carries the legacy key=value troubleshooting block;
    by default <desc> contains only the user's own notes (omitted entirely when empty).

    Returns list of (path, size_bytes, written_track_count) for manifest.
    """
    escape = xml_text

    if sort:
        features = sorted(features, key=lambda f: natural_sort_key(f.title))

    header_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<gpx xmlns="http://www.topografix.com/GPX/1/1" xmlns:onx="https://wwww.onxmaps.com/" version="1.1" creator="Cairn - CalTopo to OnX Migration Tool">',
        "  <metadata>",
        f"    <name>{escape(folder_name)}</name>",
        "  </metadata>",
    ]
    footer_line = "</gpx>"

    # region agent log
    _agent_ndjson_log(
        {
            "hypothesisId": "A",
            "location": "cairn/core/writers.py:write_gpx_tracks_maybe_split",
            "message": "Tracks GPX header namespace",
            "data": {
                "output_path": str(output_path),
                "folder_name": folder_name,
                "header_gpx_line": header_lines[1],
                "registered_ns_uri": "https://wwww.onxmaps.com/",
            },
        }
    )
    # endregion

    item_blocks: List[List[str]] = []
    written_count = 0

    for feature in features:
        if not feature.coordinates:
            continue

        sanitized_track_name, was_changed = sanitize_name_for_onx(feature.title)
        if was_changed:
            track_name_change("tracks", feature.title, sanitized_track_name)

        onx_color = (
            ColorMapper.transform_color(feature.stroke)
            if feature.stroke
            else ColorMapper.DEFAULT_COLOR
        )
        onx_style, onx_weight = line_onx_style_weight(feature)

        # region agent log
        if written_count < 3:
            _agent_ndjson_log(
                {
                    "hypothesisId": "B",
                    "location": "cairn/core/writers.py:write_gpx_tracks_maybe_split",
                    "message": "Track style mapping prior to write",
                    "data": {
                        "idx": written_count,
                        "title": feature.title,
                        "stroke_raw": getattr(feature, "stroke", None),
                        "pattern_raw": getattr(feature, "pattern", None),
                        "stroke_width_raw": getattr(feature, "stroke_width", None),
                        "onx": {
                            "color": onx_color,
                            "style": onx_style,
                            "weight": onx_weight,
                        },
                        "extensions_tag_sample": "<onx:color>/<onx:style>/<onx:weight>",
                    },
                }
            )
        # endregion

        trk_id = (getattr(feature, "id", "") or "").strip() or str(uuid.uuid4())
        notes_clean = clean_notes(feature.description or "", bool(feature.properties.get(PLAIN_NOTES_KEY)))
        desc_content = _desc_text(
            notes_clean,
            [
                f"name={feature.title}",
                f"notes={notes_clean}",
                f"id={trk_id}",
                f"color={onx_color}",
                f"style={onx_style}",
                f"weight={onx_weight}",
            ],
            debug_desc,
        )

        block: List[str] = []
        block.append("  <trk>")
        block.append(f"    <name>{escape(sanitized_track_name)}</name>")
        if desc_content:
            block.append(f"    <desc>{escape(desc_content)}</desc>")
        block.append("    <extensions>")
        block.append(f"      <onx:color>{onx_color}</onx:color>")
        block.append(f"      <onx:style>{onx_style}</onx:style>")
        block.append(f"      <onx:weight>{onx_weight}</onx:weight>")
        block.append("    </extensions>")
        block.append("    <trkseg>")

        for coord in feature.coordinates:
            if len(coord) >= 2:
                lat, lon = coord[1], coord[0]
                block.append(f'      <trkpt lat="{lat}" lon="{lon}">')
                block.extend(_trkpt_children(coord))
                block.append("      </trkpt>")

        block.append("    </trkseg>")
        block.append("  </trk>")

        item_blocks.append(block)
        written_count += 1

    if not split:
        payload = (
            header_lines + [ln for blk in item_blocks for ln in blk] + [footer_line]
        )
        output_path.write_text("\n".join(payload), encoding="utf-8")
        return [(output_path, output_path.stat().st_size, written_count)]

    full_payload = (
        header_lines + [ln for blk in item_blocks for ln in blk] + [footer_line]
    )
    if _utf8_joined_size(full_payload) <= max_bytes:
        output_path.write_text("\n".join(full_payload), encoding="utf-8")
        return [(output_path, output_path.stat().st_size, written_count)]

    parts = _split_gpx_lines_by_bytes(
        header_lines=header_lines,
        item_blocks=item_blocks,
        footer_line=footer_line,
        max_bytes=max_bytes,
    )
    written = _write_gpx_parts(parts=parts, output_path=output_path)

    out: List[tuple[Path, int, int]] = []
    for pth, sz in written:
        try:
            txt = pth.read_text(encoding="utf-8")
            cnt = txt.count("<trk>")
        except Exception:
            cnt = 0
        out.append((pth, sz, cnt))
    return out


def verify_sanitization_preserves_sort_order(
    original_names: List[str], sanitized_names: List[str]
) -> bool:
    """
    Verify that sanitization preserves natural sort order.

    Checks that if we sort both lists, items at the same index correspond to each other.

    Args:
        original_names: List of original names (in any order)
        sanitized_names: List of sanitized names (corresponding to original_names)

    Returns:
        True if sort order is preserved, False otherwise
    """
    if len(original_names) != len(sanitized_names):
        return False

    # Create pairs and sort both lists
    pairs = list(zip(original_names, sanitized_names))
    pairs_sorted_by_original = sorted(pairs, key=lambda p: natural_sort_key(p[0]))
    pairs_sorted_by_sanitized = sorted(pairs, key=lambda p: natural_sort_key(p[1]))

    # Check if the pairs are in the same order when sorted by original vs sanitized
    for i, (orig_pair, sanit_pair) in enumerate(
        zip(pairs_sorted_by_original, pairs_sorted_by_sanitized)
    ):
        if orig_pair[0] != sanit_pair[0] or orig_pair[1] != sanit_pair[1]:
            logger.warning(
                f"Sort order mismatch at position {i}: original order differs from sanitized order"
            )
            return False

    return True


def write_gpx_waypoints(
    features: List[ParsedFeature],
    output_path: Path,
    folder_name: str,
    sort: bool = True,
    add_timestamps: bool = False,
    config: Optional[IconMappingConfig] = None,
    debug_desc: bool = False,
) -> int:
    """
    Write waypoints to a GPX file with OnX namespace extensions.

    Args:
        features: List of waypoint features to write
        output_path: Path to write the GPX file
        folder_name: Name for the GPX metadata
        sort: If True (default), sort features using natural sort order
        add_timestamps: If True, add <time> elements to waypoints (for testing OnX sorting)

    Returns:
        File size in bytes

    Note:
        OnX may re-sort items after import based on name, icon type, or other criteria.
        GPX element order is respected during import but may change post-import.
        Adding timestamps is experimental and may help preserve order if OnX respects them.
    """
    # Sort features by title using natural sort
    if sort:
        features = sorted(features, key=lambda f: natural_sort_key(f.title))
        log_waypoint_order(features, "Waypoint order before write")

    # Collect original and sanitized names for verification
    original_titles = []
    sanitized_titles = []

    # Build GPX manually to ensure proper namespace handling
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<gpx xmlns="http://www.topografix.com/GPX/1/1" xmlns:onx="https://wwww.onxmaps.com/" version="1.1" creator="Cairn - CalTopo to OnX Migration Tool">',
        "  <metadata>",
        f"    <name>{xml_text(folder_name)}</name>",
        "  </metadata>",
    ]

    # Process waypoints
    for feature in features:
        if not feature.coordinates or len(feature.coordinates) < 2:
            continue

        lat, lon = feature.coordinates[1], feature.coordinates[0]

        # Map the icon (respect user config if provided), with optional per-feature override.
        mapped_icon = None
        try:
            if isinstance(getattr(feature, "properties", None), dict):
                mapped_icon = (
                    feature.properties.get("cairn_onx_icon_override") or ""
                ).strip() or None
        except Exception:
            mapped_icon = None
        if not mapped_icon:
            mapped_icon = map_icon(
                feature.title, feature.description or "", feature.symbol, config
            )

        # Track original title for verification
        original_titles.append(feature.title)

        # Format the name (optional icon prefix + sanitization)
        formatted_name = format_waypoint_name(
            feature.title,
            mapped_icon,
            use_prefix=bool(getattr(config, "use_icon_name_prefix", False)),
            default_icon=(
                getattr(config, "default_icon", "Location") if config else "Location"
            ),
        )
        sanitized_titles.append(formatted_name)

        # Escape XML special characters
        escape = xml_text

        formatted_name = escape(formatted_name)

        lines.append(f'  <wpt lat="{lat}" lon="{lon}">')
        lines.append(f"    <name>{formatted_name}</name>")

        # Add timestamp if requested (for testing OnX sorting behavior)
        # Note: GPX 1.1 spec allows <time> element in waypoints
        # OnX may use this for sorting, but testing is needed
        if add_timestamps:
            # Use ISO 8601 format: YYYY-MM-DDTHH:MM:SSZ
            # Sequential timestamps to preserve order
            timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            lines.append(f"    <time>{timestamp}</time>")

        # Waypoint color policy:
        # - If CalTopo provided a marker color, preserve intent but quantize to one of
        #   OnX's official 10 waypoint colors (OnX ignores unsupported values).
        # - Otherwise, fall back to a default color per icon type.
        # Same rule (and override key) as write_gpx_waypoints_maybe_split.
        color_override = ""
        if isinstance(getattr(feature, "properties", None), dict):
            color_override = str(
                feature.properties.get("cairn_onx_color_override") or ""
            ).strip()
        if color_override:
            onx_color = ColorMapper.map_waypoint_color(color_override)
        else:
            onx_color = resolve_waypoint_color(
                feature.color,
                mapped_icon,
                default=(
                    config.default_color
                    if config
                    else ColorMapper.DEFAULT_WAYPOINT_COLOR
                ),
            )

        # <desc> is user-facing: notes only by default; the legacy key=value
        # block (matching OnX's own export format) is available via debug_desc.
        wp_id = (getattr(feature, "id", "") or "").strip() or str(uuid.uuid4())
        notes_clean = clean_notes(feature.description or "", bool(feature.properties.get(PLAIN_NOTES_KEY)))
        desc_content = _desc_text(
            notes_clean,
            [
                f"name={feature.title}",
                f"notes={notes_clean}",
                f"id={wp_id}",
                f"color={onx_color}",
                f"icon={mapped_icon}",
            ],
            debug_desc,
        )
        if desc_content:
            lines.append(f"    <desc>{escape(desc_content)}</desc>")

        # Add OnX extensions (use lowercase `onx:` prefix to match OnX exports)
        lines.append("    <extensions>")
        lines.append(f"      <onx:icon>{escape(mapped_icon)}</onx:icon>")
        lines.append(f"      <onx:color>{onx_color}</onx:color>")
        lines.append("    </extensions>")
        lines.append("  </wpt>")

    lines.append("</gpx>")

    # Write to file
    output_path.write_text("\n".join(lines), encoding="utf-8")

    # Verify that sanitization preserved sort order
    if sort and len(original_titles) == len(sanitized_titles):
        order_preserved = verify_sanitization_preserves_sort_order(
            [
                f.title
                for f in sorted(features, key=lambda f: natural_sort_key(f.title))
            ],
            sanitized_titles,
        )
        if not order_preserved:
            logger.warning(
                "Sanitization may have affected sort order - this should not happen"
            )

    # Verify order after write (debug only)
    if logger.isEnabledFor(logging.DEBUG):
        gpx_order = verify_gpx_waypoint_order(output_path)
        if gpx_order:
            logger.debug("[DEBUG] Waypoint order in GPX file:")
            for i, name in enumerate(gpx_order, 1):
                logger.debug(f"  {i}. {name}")

    return output_path.stat().st_size


def write_gpx_tracks(
    features: List[ParsedFeature],
    output_path: Path,
    folder_name: str,
    sort: bool = True,
    debug_desc: bool = False,
) -> int:
    """
    Write tracks to a GPX file with OnX namespace extensions for color, style, and weight.

    Args:
        features: List of track features to write
        output_path: Path to write the GPX file
        folder_name: Name for the GPX metadata
        sort: If True (default), sort and reverse features for OnX display order

    Returns:
        File size in bytes

    Note:
        OnX displays items in the same order as the GPX file.
    """
    escape = xml_text

    # Sort features by title using natural sort
    if sort:
        features = sorted(features, key=lambda f: natural_sort_key(f.title))

    # Build GPX manually with OnX namespace
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<gpx xmlns="http://www.topografix.com/GPX/1/1" xmlns:onx="https://wwww.onxmaps.com/" version="1.1" creator="Cairn - CalTopo to OnX Migration Tool">',
        "  <metadata>",
        f"    <name>{escape(folder_name)}</name>",
        "  </metadata>",
    ]

    # Process tracks
    for feature in features:
        if not feature.coordinates:
            continue

        # Sanitize track name for OnX sorting compatibility
        sanitized_track_name, was_changed = sanitize_name_for_onx(feature.title)
        if was_changed:
            track_name_change("tracks", feature.title, sanitized_track_name)

        lines.append("  <trk>")
        lines.append(f"    <name>{escape(sanitized_track_name)}</name>")

        # Map CalTopo stroke color to closest OnX color
        onx_color = (
            ColorMapper.transform_color(feature.stroke)
            if feature.stroke
            else ColorMapper.DEFAULT_COLOR
        )
        onx_style, onx_weight = line_onx_style_weight(feature)

        # <desc> is user-facing: notes only by default; the legacy key=value
        # block (matching OnX's own export format) is available via debug_desc.
        trk_id = (getattr(feature, "id", "") or "").strip() or str(uuid.uuid4())
        notes_clean = clean_notes(feature.description or "", bool(feature.properties.get(PLAIN_NOTES_KEY)))
        desc_content = _desc_text(
            notes_clean,
            [
                f"name={feature.title}",
                f"notes={notes_clean}",
                f"id={trk_id}",
                f"color={onx_color}",
                f"style={onx_style}",
                f"weight={onx_weight}",
            ],
            debug_desc,
        )
        if desc_content:
            lines.append(f"    <desc>{escape(desc_content)}</desc>")

        # Add OnX extensions for color, style, and weight (use lowercase `onx:` prefix)
        lines.append("    <extensions>")
        lines.append(f"      <onx:color>{onx_color}</onx:color>")

        # Map CalTopo pattern to OnX style
        lines.append(f"      <onx:style>{onx_style}</onx:style>")

        # Map CalTopo stroke-width to OnX weight
        lines.append(f"      <onx:weight>{onx_weight}</onx:weight>")

        lines.append("    </extensions>")

        lines.append("    <trkseg>")

        # Add track points
        for coord in feature.coordinates:
            if len(coord) >= 2:
                lat, lon = coord[1], coord[0]
                lines.append(f'      <trkpt lat="{lat}" lon="{lon}">')
                lines.extend(_trkpt_children(coord))
                lines.append("      </trkpt>")

        lines.append("    </trkseg>")
        lines.append("  </trk>")

    lines.append("</gpx>")

    # Write to file
    output_path.write_text("\n".join(lines), encoding="utf-8")

    return output_path.stat().st_size


# --- KML areas -------------------------------------------------------------
#
# Size cap: onX documents a 4 MB import limit for GPX; KML is ASSUMED to share
# it (unverified). Area files are split at the same 3.75 MiB as GPX so a large
# map never produces one oversized KML.
DEFAULT_MAX_KML_BYTES = DEFAULT_MAX_GPX_BYTES

# KML <width> when CalTopo gives no stroke-width (the writer's historical value).
_DEFAULT_KML_WIDTH = "2"


def _is_position(p) -> bool:
    return (
        isinstance(p, (list, tuple))
        and len(p) >= 2
        and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in p[:2])
        and all(math.isfinite(float(v)) for v in p[:2])
    )


def _polygon_rings(coordinates) -> List[List[list]]:
    """Normalize a Polygon's coordinates into [outer, hole, hole, ...].

    GeoJSON Polygon coordinates are a list of linear rings, the first the
    outer boundary and the rest holes. Depth is detected from the data rather
    than trusted: a bare ring (one level too shallow) is accepted as the outer
    ring, and a MultiPolygon-shaped array (one level too deep) contributes its
    FIRST polygon only. Invalid positions are dropped; a ring with fewer than 3
    usable positions is discarded. Returns [] when there is no usable outer
    ring -- the caller then skips the feature and does not count it.
    """
    c = coordinates
    if not isinstance(c, (list, tuple)) or not c:
        return []
    # Peel down to "list of rings" (each ring a list of positions).
    if _is_position(c[0]):
        c = [c]  # a single bare ring
    elif (
        isinstance(c[0], (list, tuple))
        and c[0]
        and all(isinstance(r, (list, tuple)) for r in c[0])
        and not any(_is_position(r) for r in c[0])
        and any(
            isinstance(r, (list, tuple)) and any(_is_position(q) for q in r)
            for r in c[0]
        )
    ):
        # c[0] holds no positions but holds rings: MultiPolygon-shaped, so
        # take its first polygon. (A Polygon whose first vertex alone is bad
        # still has positions in c[0] and is NOT misread as this.)
        c = c[0]
    rings: List[List[list]] = []
    for idx, ring in enumerate(c):
        if not isinstance(ring, (list, tuple)):
            continue
        pts = [list(p) for p in ring if _is_position(p)]
        if len(pts) < 3:
            if idx == 0:
                return []  # no usable outer boundary
            continue
        if pts[0][:2] != pts[-1][:2]:
            pts.append(list(pts[0]))  # KML LinearRings must be closed
        rings.append(pts)
    return rings


def _rgba_to_kml(rgba: str, alpha: int) -> str:
    """onX rgba(...) -> KML aabbggrr with the given alpha (0-255)."""
    r, g, b = ColorMapper.parse_color(rgba)
    return f"{alpha:02x}{b:02x}{g:02x}{r:02x}"


def _opacity_alpha(value, default: int) -> int:
    """CalTopo opacity (0..1) -> 0..255 alpha; missing/malformed -> default."""
    if value is None or isinstance(value, bool):
        return default
    try:
        v = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(v):
        return default
    return int(round(max(0.0, min(1.0, v)) * 255))


def kml_area_color(feature: ParsedFeature) -> str:
    """The onX rgba an area is exported (and shown in the web UI) with.

    Nearest of onX's 11-color TRACK palette to the CalTopo stroke (falling back
    to marker-color). Missing or malformed -> Blue, via parse_color's default --
    the same value web/bridge.py displays. A user color edit reaches here as the
    rewritten feature.stroke, so it wins.
    """
    return ColorMapper.map_track_color(
        getattr(feature, "stroke", "") or getattr(feature, "color", "") or ""
    )


def line_onx_style_weight(feature: ParsedFeature) -> tuple[str, str]:
    """(style, weight) a track is written with.

    The exact onX value pinned in properties (LINE_STYLE_KEY / LINE_WEIGHT_KEY:
    an onX file's own value, including "dot" and "2.0", or the user's edit),
    else CalTopo's pattern and stroke-width mapped by pattern_to_style /
    stroke_width_to_weight. onX keeps all three styles and weights on import
    (docs/ONX_ROUND_TRIP.md #area-fidelity), so nothing it supports is rounded.
    """
    props = getattr(feature, "properties", None) or {}
    style = (props.get(LINE_STYLE_KEY) or "").strip()
    if style not in ONX_LINE_STYLES:
        style = pattern_to_style(getattr(feature, "pattern", "") or "")
    weight = str(props.get(LINE_WEIGHT_KEY) or "").strip()
    if weight not in ONX_LINE_WEIGHTS:
        weight = stroke_width_to_weight(getattr(feature, "stroke_width", None))
    return style, weight


def area_onx_style(feature: ParsedFeature) -> tuple[str, str, str, str]:
    """(color, style, weight, fill_color): the onX values an area is written with.

    The one rule every area writer (GPX and KML) and web/bridge.py share.

    - color: kml_area_color (11-colour line palette; onX areas use the same one).
    - style / weight: the exact onX value pinned in properties (AREA_STYLE_KEY /
      AREA_WEIGHT_KEY -- an onX file's own value, including "dot" and "2.0", or
      the user's edit), else CalTopo's pattern and stroke-width mapped as for
      tracks (pattern_to_style, stroke_width_to_weight).
    - fill: the pinned onX fill (AREA_FILL_KEY) or CalTopo's fill colour, else
      the area's line colour, mapped to the nearest of onX's 10 fill swatches;
      CalTopo fill-opacity 0, or a transparent rgba, is onX's "none". onX's
      importer ignores the fill (2026-10-23, docs/ONX_ROUND_TRIP.md
      #area-fidelity); it is written to match onX's own export.
    """
    props = getattr(feature, "properties", None) or {}
    color = kml_area_color(feature)
    style = (props.get(AREA_STYLE_KEY) or "").strip()
    if style not in ONX_LINE_STYLES:
        style = pattern_to_style(getattr(feature, "pattern", "") or "")
    weight = str(props.get(AREA_WEIGHT_KEY) or "").strip()
    if weight not in ONX_LINE_WEIGHTS:
        weight = stroke_width_to_weight(props.get("stroke-width", getattr(feature, "stroke_width", None)))
    pinned = (props.get(AREA_FILL_KEY) or "").strip()
    if pinned:
        fill = ColorMapper.map_area_fill(pinned)
    else:
        source = (getattr(feature, "fill", "") or "").strip() or (getattr(feature, "stroke", "") or "").strip() or color
        fill = ColorMapper.map_area_fill(source, getattr(feature, "fill_opacity", None))
    return color, style, weight, fill


def _fill_alpha_255(fill_rgba: str) -> int:
    """onX fill rgba -> 0..255 alpha for a KML PolyStyle (none -> 0, swatch -> 0.1)."""
    m = re.match(r"rgba\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*([\d.]+)\s*\)", fill_rgba or "")
    return _opacity_alpha(m.group(1) if m else None, 0)


def _kml_placemark(feature: ParsedFeature) -> Optional[ET.Element]:
    """Build one area Placemark, or None when the polygon has no usable ring."""
    rings = _polygon_rings(feature.coordinates)
    if not rings:
        return None

    placemark = ET.Element("Placemark")

    name_elem = ET.SubElement(placemark, "name")
    # Same sanitizing rule as waypoint/track names (see _name_changes above).
    sanitized, was_changed = sanitize_name_for_onx(feature.title)
    if was_changed:
        track_name_change("shapes", feature.title, sanitized)
    name_elem.text = xml_safe(sanitized)

    notes_text = clean_notes(feature.description or "", bool(feature.properties.get(PLAIN_NOTES_KEY)))
    if notes_text:
        desc = ET.SubElement(placemark, "description")
        desc.text = xml_safe(notes_text)

    # Style. VERIFIED 2026-10-22 (ENG-05): onX's importer IGNORES this style --
    # a real Web Map import of these Placemarks (inline Style, a shared styleUrl
    # style, and the ExtendedData below) came in with onX's default area style.
    # They still carry the area's values in standard KML 2.2 for other KML
    # consumers and for read_onx_kml; the web export writes areas with
    # write_gpx_areas_maybe_split instead. KML 2.2 has no dash pattern, so the
    # style travels only in the ExtendedData below.
    area_rgba, area_style, area_weight, fill_rgba = area_onx_style(feature)
    style = ET.SubElement(placemark, "Style")
    line_style = ET.SubElement(style, "LineStyle")
    ET.SubElement(line_style, "color").text = _rgba_to_kml(
        area_rgba, _opacity_alpha(getattr(feature, "stroke_opacity", None), 0xFF)
    )
    width = _DEFAULT_KML_WIDTH
    raw_width = (getattr(feature, "properties", None) or {}).get("stroke-width")
    try:
        w = float(raw_width)
        if math.isfinite(w) and w > 0:
            width = f"{w:g}"
    except (TypeError, ValueError):
        pass
    ET.SubElement(line_style, "width").text = width

    # Fill: the same onX swatch the GPX writer writes (area_onx_style), at its
    # own alpha (0.1 -> 1a; onX's "none" -> 00, outline only).
    poly_style = ET.SubElement(style, "PolyStyle")
    ET.SubElement(poly_style, "color").text = _rgba_to_kml(fill_rgba, _fill_alpha_255(fill_rgba))

    # The same values again as onX-style ExtendedData, the way onX's own KML export
    # (mapbox tokml) carries every property (KG section 3.5). This is what lets
    # read_onx_kml read Cairn's KML and onX's alike: notes, colour, line style,
    # weight and fill all come back. Placed after <Style>, before the geometry, per
    # the KML 2.2 Placemark element order. VERIFIED 2026-10-22: onX's importer
    # reads neither these Data fields nor the <Style> for an area's colour/fill.
    onx_data = []
    if notes_text:
        onx_data.append(("notes", notes_text))
    onx_data += [
        ("color", area_rgba),
        ("style", area_style),
        ("weight", area_weight),
        ("fill_color", fill_rgba),
    ]
    extended = ET.SubElement(placemark, "ExtendedData")
    for key, value in onx_data:
        data = ET.SubElement(extended, "Data")
        data.set("name", key)
        ET.SubElement(data, "value").text = xml_safe(value)

    polygon = ET.SubElement(placemark, "Polygon")
    for i, ring in enumerate(rings):
        boundary = ET.SubElement(
            polygon, "outerBoundaryIs" if i == 0 else "innerBoundaryIs"
        )
        linear_ring = ET.SubElement(boundary, "LinearRing")
        coords_elem = ET.SubElement(linear_ring, "coordinates")
        coords_elem.text = " ".join(
            f"{p[0]},{p[1]},{p[2] if len(p) > 2 else 0}" for p in ring
        )
    return placemark


def _kml_document(folder_name: str, placemarks: List[ET.Element]) -> str:
    kml = ET.Element("kml")
    kml.set("xmlns", "http://www.opengis.net/kml/2.2")
    document = ET.SubElement(kml, "Document")
    ET.SubElement(document, "name").text = xml_safe(folder_name)
    # Generator marker, so cairn/io/input_check.detect can tell Cairn's KML
    # from CalTopo's or Google Earth's (KG section 5.1). Document-level
    # ExtendedData is valid KML 2.2 and sits outside every Placemark, so it
    # cannot leak into an item's properties (onx_kml reads Data per Placemark,
    # and onX's own tokml/togeojson-style handling is per feature). UNVERIFIED:
    # whether onX's importer shows or keeps it -- nothing suggests it does.
    # It lives here, not in the callers, so write_kml_shapes_maybe_split's
    # empty-document size baseline already includes it.
    marker = ET.SubElement(ET.SubElement(document, "ExtendedData"), "Data")
    marker.set("name", "generator")
    ET.SubElement(marker, "value").text = "Cairn"
    for pm in placemarks:
        document.append(pm)
    return prettify_xml(kml)


def write_kml_shapes_maybe_split(
    features: List[ParsedFeature],
    output_path: Path,
    folder_name: str,
    *,
    split: bool = True,
    max_bytes: int = DEFAULT_MAX_KML_BYTES,
) -> List[tuple[Path, int, int]]:
    """Write areas (polygons) to KML, splitting into numbered parts
    (`<stem>_1.kml`, `<stem>_2.kml`, ...) like the GPX writers when one file
    would exceed max_bytes. Preserves order.

    Returns [(path, size_bytes, written_placemark_count)]. Polygons with no
    usable outer ring are skipped and NOT counted, so callers can report them
    as dropped. When nothing is writable an empty file set is still produced
    (one file, count 0) to keep the old single-file contract.
    """
    import copy

    placemarks = [pm for pm in (_kml_placemark(f) for f in features) if pm is not None]

    full = _kml_document(folder_name, [copy.deepcopy(pm) for pm in placemarks])
    if not split or len(full.encode("utf-8")) <= max_bytes or len(placemarks) <= 1:
        output_path.write_text(full, encoding="utf-8")
        return [(output_path, output_path.stat().st_size, len(placemarks))]

    # Measure each placemark as it serializes inside a document, then pack
    # greedily. Each part is rebuilt from fresh copies (ET.indent mutates).
    empty = len(_kml_document(folder_name, []).encode("utf-8"))
    sizes = [
        len(_kml_document(folder_name, [copy.deepcopy(pm)]).encode("utf-8")) - empty
        for pm in placemarks
    ]
    # The empty <Document> serializes its closing tag differently from a
    # populated one; a small margin absorbs that difference.
    budget = max_bytes - empty - 64
    groups: List[List[ET.Element]] = []
    cur: List[ET.Element] = []
    cur_size = 0
    for pm, sz in zip(placemarks, sizes):
        if cur and cur_size + sz > budget:
            groups.append(cur)
            cur, cur_size = [], 0
        if not cur and sz > budget:
            logger.warning(
                f"A single KML area exceeds max_bytes={max_bytes} ({sz + empty} bytes). "
                f"Writing it as a single-part file anyway."
            )
        cur.append(pm)
        cur_size += sz
    if cur:
        groups.append(cur)

    if len(groups) == 1:
        output_path.write_text(full, encoding="utf-8")
        return [(output_path, output_path.stat().st_size, len(placemarks))]

    out: List[tuple[Path, int, int]] = []
    for i, group in enumerate(groups, 1):
        part_path = output_path.with_name(f"{output_path.stem}_{i}{output_path.suffix}")
        part_path.write_text(
            _kml_document(folder_name, [copy.deepcopy(pm) for pm in group]),
            encoding="utf-8",
        )
        out.append((part_path, part_path.stat().st_size, len(group)))
    return out


def write_kml_shapes(
    features: List[ParsedFeature], output_path: Path, folder_name: str
) -> int:
    """Write areas to ONE KML file (no splitting). Returns the file size.

    Kept for existing callers; new code should use write_kml_shapes_maybe_split,
    which also reports how many areas were actually written.
    """
    (path, size, _count), = write_kml_shapes_maybe_split(
        features, output_path, folder_name, split=False
    )
    return size


# --- Areas as GPX <rte> (ENG-05) -------------------------------------------------
#
# VERIFIED 2026-10-22 in a real onX Web Map import: onX ignores an area's colour
# and fill in KML (LineStyle/PolyStyle, a shared styleUrl and onX-style
# ExtendedData all came in as onX's default red outline / blue 10% fill), but
# a GPX <rte> with <type>Area</type> and onX extensions imports as a real onX
# Area -- the shape onX's own GPX export uses. VERIFIED 2026-10-23
# (docs/ONX_ROUND_TRIP.md#area-fidelity): onX's GPX importer keeps
# <onx:color>, <onx:style> (solid / dash / dot) and <onx:weight> (2.0 / 4.0 /
# 6.0), and never reads the fill -- not onX's own swatch strings, not "none",
# not any of eight other encodings; every imported area gets the default
# rgba(74,144,226,0.1). <onx:fill_color> is still written, as the nearest onX
# swatch, to match onX's own export. So areas are exported this way; the KML
# writer above is kept for its other callers. onX areas are single-ring: a
# polygon's holes cannot be written and are reported (get_areas_without_holes)
# rather than dropped silently.

# Titles of areas whose holes were not written, since the last clear.
_areas_without_holes: List[str] = []
# The same areas by position among the areas written (0-based, in file order
# across split parts), so a report can mark the very area when names repeat.
_area_hole_positions: List[int] = []


def get_areas_without_holes() -> List[str]:
    """Titles of areas exported with their outer ring only (holes not kept)."""
    return list(_areas_without_holes)


def get_area_hole_positions() -> List[int]:
    """Positions (0-based, in written order) of the areas get_areas_without_holes names."""
    return list(_area_hole_positions)


def clear_areas_without_holes() -> None:
    """Reset the holes record (call before processing a new folder)."""
    _areas_without_holes.clear()
    _area_hole_positions.clear()


def write_gpx_areas_maybe_split(
    features: List[ParsedFeature],
    output_path: Path,
    folder_name: str,
    *,
    sort: bool = True,
    split: bool = True,
    max_bytes: int = DEFAULT_MAX_GPX_BYTES,
    debug_desc: bool = False,
) -> List[tuple[Path, int, int]]:
    """Write areas (polygons) to GPX as onX Area routes, splitting like the
    other GPX writers. Preserves order (after the optional natural sort).

    Each area is one <rte>: <name>, <desc> (the user's note only; omitted when
    empty), <type>Area</type>, <extensions> with <onx:color>, <onx:style>,
    <onx:weight> and <onx:fill_color> (area_onx_style, the values the web UI
    shows), then the closed OUTER ring as <rtept lat lon/> -- the element order
    of onX's own export. Holes
    are not representable; such areas are recorded in get_areas_without_holes.

    Returns [(path, size_bytes, written_area_count)]. Polygons with no usable
    outer ring are skipped and NOT counted, so callers can report them as
    dropped.
    """
    escape = xml_text

    if sort:
        features = sorted(features, key=lambda f: natural_sort_key(f.title or ""))

    header_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<gpx xmlns="http://www.topografix.com/GPX/1/1" xmlns:onx="https://wwww.onxmaps.com/" version="1.1" creator="Cairn - CalTopo to OnX Migration Tool">',
        "  <metadata>",
        f"    <name>{escape(folder_name)}</name>",
        "  </metadata>",
    ]
    footer_line = "</gpx>"

    item_blocks: List[List[str]] = []
    for feature in features:
        rings = _polygon_rings(feature.coordinates)
        if not rings:
            continue
        sanitized, was_changed = sanitize_name_for_onx(feature.title)
        if was_changed:
            track_name_change("shapes", feature.title, sanitized)
        if len(rings) > 1:
            _areas_without_holes.append(sanitized)
            _area_hole_positions.append(len(item_blocks))

        area_rgba, area_style, area_weight, fill_rgba = area_onx_style(feature)
        notes_clean = clean_notes(feature.description or "", bool(feature.properties.get(PLAIN_NOTES_KEY)))
        area_id = (getattr(feature, "id", "") or "").strip() or str(uuid.uuid4())
        desc_content = _desc_text(
            notes_clean,
            [
                f"name={feature.title}",
                f"notes={notes_clean}",
                f"id={area_id}",
                "type=Area",
                f"color={area_rgba}",
                f"style={area_style}",
                f"weight={area_weight}",
                f"fill_color={fill_rgba}",
            ],
            debug_desc,
        )

        block: List[str] = ["  <rte>", f"    <name>{escape(sanitized)}</name>"]
        if desc_content:
            block.append(f"    <desc>{escape(desc_content)}</desc>")
        block.append("    <type>Area</type>")
        block.append("    <extensions>")
        block.append(f"      <onx:color>{area_rgba}</onx:color>")
        block.append(f"      <onx:style>{area_style}</onx:style>")
        block.append(f"      <onx:weight>{area_weight}</onx:weight>")
        block.append(f"      <onx:fill_color>{fill_rgba}</onx:fill_color>")
        block.append("    </extensions>")
        # Bare lat/lon, as in onX's own area export (the verified import used
        # no <ele>); _polygon_rings already closed the ring.
        for p in rings[0]:
            block.append(f'    <rtept lat="{p[1]}" lon="{p[0]}"/>')
        block.append("  </rte>")
        item_blocks.append(block)

    written_count = len(item_blocks)
    full_payload = header_lines + [ln for blk in item_blocks for ln in blk] + [footer_line]
    if not split or _utf8_joined_size(full_payload) <= max_bytes:
        output_path.write_text("\n".join(full_payload), encoding="utf-8")
        return [(output_path, output_path.stat().st_size, written_count)]

    parts = _split_gpx_lines_by_bytes(
        header_lines=header_lines,
        item_blocks=item_blocks,
        footer_line=footer_line,
        max_bytes=max_bytes,
    )
    out: List[tuple[Path, int, int]] = []
    for pth, sz in _write_gpx_parts(parts=parts, output_path=output_path):
        out.append((pth, sz, pth.read_text(encoding="utf-8").count("<rte>")))
    return out
