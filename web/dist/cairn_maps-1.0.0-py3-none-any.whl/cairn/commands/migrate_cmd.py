"""\
Migration-focused CLI commands.

These are thin wrappers around the conversion pipeline that prioritize:
- clear intent (one command per migration direction)
- sensible defaults (dedupe on, polygon preference)
- predictable output locations and filenames

This module is intentionally UX-focused: interactive prompting, progress output,
and a clean summary of generated artifacts.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Tuple

if TYPE_CHECKING:
    from cairn.core.parser import ParsedData

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from cairn.ui.interactive import InteractiveUI, is_interactive_tty

from cairn.core.dedup import apply_waypoint_dedup
from cairn.core.diagnostics import (
    check_data_quality,
    dedup_inventory,
    document_inventory,
)
from cairn.core.icon_registry import IconRegistry, write_icon_report_markdown
from cairn.core.merge import merge_onx_gpx_and_kml
from cairn.core.shape_dedup import apply_shape_dedup
from cairn.core.trace import TraceWriter
from cairn.io.caltopo_geojson import write_caltopo_geojson
from cairn.io.onx_gpx import read_onx_gpx
from cairn.io.onx_kml import read_onx_kml
from cairn.model import MapDocument
from cairn.utils.utils import ensure_output_dir, format_file_size


app = typer.Typer(
    no_args_is_help=True,
    help="""
Migration helpers for OnX Backcountry ↔ CalTopo.

Currently supported:
  onx-to-caltopo      Migrate OnX exports to CalTopo GeoJSON
  caltopo-to-onx      Migrate CalTopo GeoJSON to OnX GPX/KML

The migration workflow is designed to preserve all map customization
(icons, colors, notes, organization) - not just raw shapes.
    """.strip(),
)
console = Console()
ui = InteractiveUI(console=console)


def _display_path(p: Path) -> str:
    """Prefer a relative path; fall back to filename."""
    try:
        return str(p.resolve().relative_to(Path.cwd().resolve()))
    except Exception:
        return p.name


def _find_export_files(directory: Path) -> Tuple[List[Path], List[Path]]:
    """
    Find GPX and KML files in directory.

    Returns:
        (gpx_files, kml_files) - sorted by modification time (newest first)
    """
    gpx_files = sorted(
        directory.glob("*.gpx"), key=lambda p: p.stat().st_mtime, reverse=True
    )
    kml_files = sorted(
        directory.glob("*.kml"), key=lambda p: p.stat().st_mtime, reverse=True
    )
    return gpx_files, kml_files


def _as_existing_path(p: Optional[Path]) -> Optional[Path]:
    if p is None:
        return None
    p2 = p.expanduser().resolve()
    return p2 if p2.exists() else None


def _reorder_prefer_first(paths: List[Path], preferred: Optional[Path]) -> List[Path]:
    if preferred is None:
        return paths
    pref = preferred.expanduser().resolve()
    out = [p for p in paths if p.resolve() == pref]
    out.extend([p for p in paths if p.resolve() != pref])
    return out


def _run_onx_to_caltopo_pipeline(
    *,
    gpx: Path,
    kml: Optional[Path],
    out_dir: Path,
    base: str,
    dedupe_waypoints: bool,
    dedupe_shapes: bool,
    trace: bool,
    trace_path: Optional[Path],
    description_mode: str,
    route_color_strategy: str,
) -> None:
    primary_path = out_dir / f"{base}.json"
    dropped_shapes_path = out_dir / f"{base}_dropped_shapes.json"

    resolved_trace_path: Optional[Path]
    if not trace:
        resolved_trace_path = None
    elif trace_path is not None:
        resolved_trace_path = trace_path.expanduser()
        resolved_trace_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        resolved_trace_path = out_dir / f"{base}_trace.jsonl"

    trace_ctx = TraceWriter(resolved_trace_path) if resolved_trace_path else None
    try:
        if trace_ctx:
            trace_ctx.emit({"event": "run.start", "command": "migrate.OnX-to-caltopo"})

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Migrating OnX → CalTopo", total=7)

            progress.update(task, description="Reading GPX")
            try:
                doc = read_onx_gpx(gpx, trace=trace_ctx)
            except ValueError as e:
                progress.stop()
                console.print("\n[bold red]❌ Error reading GPX file:[/]")
                console.print(f"[red]{e}[/]")
                raise typer.Exit(1)
            progress.advance(task)

            kml_doc = None
            if kml is not None:
                progress.update(task, description="Reading KML")
                try:
                    kml_doc = read_onx_kml(kml, trace=trace_ctx)
                except ValueError as e:
                    progress.stop()
                    console.print("\n[bold red]❌ Error reading KML file:[/]")
                    console.print(f"[red]{e}[/]")
                    raise typer.Exit(1)
                progress.advance(task)
            else:
                progress.update(task, description="Skipping KML (none provided)")
                progress.advance(task)

            progress.update(task, description="Merging GPX + KML (prefer polygons)")
            if kml_doc is not None:
                doc = merge_onx_gpx_and_kml(doc, kml_doc, trace=trace_ctx)
            progress.advance(task)

            # Icon inventory + mapping report (before dedup so it reflects incoming data)
            try:
                registry = IconRegistry()
                onx_icon_inventory = registry.collect_onx_icon_inventory(doc)
                onx_icon_rows = registry.collect_onx_icon_mapping_rows(doc)

                # Append to repo catalog (policy: append catalog only; no auto-mapping)
                registry.append_onx_icon_inventory_to_catalog(onx_icon_inventory)

                icon_report_path = out_dir / f"{base}_ICON_REPORT.md"
                write_icon_report_markdown(
                    output_path=icon_report_path,
                    title="OnX → CalTopo icon report",
                    rows=onx_icon_rows,
                    inventories=onx_icon_inventory,
                    notes=(
                        f"Mappings source: `{registry.mappings_path}`",
                        f"Catalog updated: `{registry.catalog_path}`",
                        "Counts reflect input after GPX+KML merge and before dedup.",
                    ),
                )
                if trace_ctx:
                    trace_ctx.emit(
                        {
                            "event": "icons.report",
                            "direction": "onx_to_caltopo",
                            "report_path": str(icon_report_path),
                            "unique_icons": len(onx_icon_inventory),
                        }
                    )
            except Exception as e:
                # Non-fatal: migration output should not depend on report/catalog.
                if trace_ctx:
                    trace_ctx.emit({"event": "icons.report.error", "error": str(e)})

            if trace_ctx:
                trace_ctx.emit(
                    {"event": "inventory.before_dedup", **document_inventory(doc)}
                )

            # Check data quality and show warnings
            progress.update(task, description="Checking data quality")
            quality_warnings = check_data_quality(doc)
            if trace_ctx:
                trace_ctx.emit({"event": "data_quality.check", **quality_warnings})

            wp_report = None
            if dedupe_waypoints:
                progress.update(task, description="Deduplicating waypoints")
                wp_report = apply_waypoint_dedup(doc, trace=trace_ctx)
                if trace_ctx and wp_report is not None:
                    trace_ctx.emit(
                        {"event": "dedup.report", **dedup_inventory(wp_report)}
                    )
            else:
                progress.update(task, description="Skipping waypoint dedup")
            progress.advance(task)

            progress.update(task, description="Deduplicating shapes")
            shape_report = None
            dropped_items = []
            if dedupe_shapes:
                shape_report, dropped_items = apply_shape_dedup(doc, trace=trace_ctx)
            progress.advance(task)

            progress.update(task, description="Writing CalTopo GeoJSON")
            desc_mode_norm = (description_mode or "").strip().lower().replace("-", "_")
            if desc_mode_norm in ("notes_only", "notes"):
                desc_mode_norm = "notes_only"
            elif desc_mode_norm != "debug":
                raise typer.BadParameter(
                    "--description-mode must be one of: notes-only, debug"
                )

            route_color_norm = (
                (route_color_strategy or "").strip().lower().replace("-", "_")
            )
            if route_color_norm == "defaultblue":
                route_color_norm = "default_blue"
            if route_color_norm not in ("palette", "default_blue", "none"):
                raise typer.BadParameter(
                    "--route-color-strategy must be one of: palette, default-blue, none"
                )

            # Icon report + catalog (best-effort; never fails the migration)
            try:
                reg = IconRegistry()
                inventory = reg.collect_onx_icon_inventory(doc)
                rows = reg.collect_onx_icon_mapping_rows(doc)
                icon_report_path = out_dir / f"{base}_ICON_REPORT.md"
                write_icon_report_markdown(
                    output_path=icon_report_path,
                    title="OnX → CalTopo icon mapping report",
                    inventories=inventory,
                    rows=rows,
                    notes=(
                        [
                            f"Input GPX: `{gpx.name}`",
                            f"Input KML: `{kml.name if kml else 'None'}`",
                            f"Output GeoJSON: `{primary_path.name}`",
                        ]
                    ),
                )
                reg.append_onx_icon_inventory_to_catalog(inventory)
            except Exception as e:
                if trace_ctx:
                    trace_ctx.emit({"event": "icon_report.error", "error": str(e)})

            write_caltopo_geojson(
                doc,
                primary_path,
                trace=trace_ctx,
                description_mode=desc_mode_norm,  # type: ignore[arg-type]
                route_color_strategy=route_color_norm,  # type: ignore[arg-type]
            )

            # Validate output file was written successfully
            if not primary_path.exists():
                progress.stop()
                console.print(
                    "\n[bold red]❌ Error:[/] Failed to write primary output file"
                )
                raise typer.Exit(1)

            primary_size = primary_path.stat().st_size
            if primary_size < 100:  # Suspiciously small file
                progress.stop()
                console.print(
                    f"\n[yellow]⚠️  Warning:[/] Output file is very small ({primary_size} bytes)"
                )
                console.print(
                    "[yellow]This may indicate data loss. Please verify the output.[/]"
                )

            progress.advance(task)

            progress.update(task, description="Writing dropped-duplicates GeoJSON")
            dropped_doc = MapDocument(
                folders=list(doc.folders),
                items=list(dropped_items),
                metadata={
                    "source": "cairn_shape_dedup_dropped",
                    "primary": str(primary_path),
                },
            )
            write_caltopo_geojson(
                dropped_doc,
                dropped_shapes_path,
                trace=trace_ctx,
                description_mode=desc_mode_norm,  # type: ignore[arg-type]
                route_color_strategy=route_color_norm,  # type: ignore[arg-type]
            )

            # Validate secondary files were written
            if not dropped_shapes_path.exists():
                progress.stop()
                console.print(
                    "\n[yellow]⚠️  Warning:[/] Some output files may not have been written correctly"
                )

            progress.advance(task)

        console.print("\n[bold green]Done.[/]")

        # Show data quality warnings if any
        if quality_warnings:
            if quality_warnings["empty_names"]:
                console.print(
                    f"\n[yellow]⚠️  Found {len(quality_warnings['empty_names'])} item(s) with empty/default names[/]"
                )
            if quality_warnings["duplicate_names"]:
                console.print(
                    f"\n[yellow]⚠️  Found {len(quality_warnings['duplicate_names'])} duplicate name(s) (will be deduplicated if enabled)[/]"
                )
            if quality_warnings["suspicious_coords"]:
                console.print(
                    f"\n[yellow]⚠️  Found {len(quality_warnings['suspicious_coords'])} waypoint(s) with suspicious coordinates near (0,0)[/]"
                )

        console.print("\n[bold]Created files:[/]")

        console.print("\nPrimary CalTopo-importable GeoJSON (deduped by default):")
        console.print(
            f"- [cyan]{_display_path(primary_path)}[/] [dim]({primary_size:,} bytes)[/]"
        )

        dropped_size = (
            dropped_shapes_path.stat().st_size if dropped_shapes_path.exists() else 0
        )
        console.print("\nDropped duplicate shapes preserved as GeoJSON:")
        console.print(
            f"- [cyan]{_display_path(dropped_shapes_path)}[/] [dim]({dropped_size:,} bytes)[/]"
        )

        if resolved_trace_path is not None:
            console.print(
                "\nMachine-parseable trace log (JSON Lines) for debugging/replay:"
            )
            console.print(f"- [cyan]{_display_path(resolved_trace_path)}[/]")

        icon_report_path = out_dir / f"{base}_ICON_REPORT.md"
        if icon_report_path.exists():
            console.print(
                "\nIcon mapping report (incoming icons → mapped symbols + colors):"
            )
            console.print(f"- [cyan]{_display_path(icon_report_path)}[/]")
    finally:
        if trace_ctx:
            trace_ctx.emit({"event": "run.end"})
            trace_ctx.close()


def _select_files_interactive(
    gpx_files: List[Path], kml_files: List[Path], *, force_interactive: Optional[bool] = None
) -> Tuple[Optional[Path], Optional[Path]]:
    """
    Display available files and prompt user to select.

    Returns:
        (selected_gpx, selected_kml) or (None, None) if cancelled
    """
    console.print("\n[bold]Found export files:[/]")

    if not gpx_files:
        console.print("[red]No GPX files found[/]")
        return None, None

    def _label(p: Path) -> str:
        try:
            size = p.stat().st_size
            mtime = datetime.fromtimestamp(p.stat().st_mtime)
            return f"{p.name} ({format_file_size(size)}, {mtime:%Y-%m-%d %H:%M})"
        except Exception:
            return p.name

    # Prefer prompt-toolkit selection when interactive; fallback to existing numeric prompts otherwise.
    if is_interactive_tty(force=force_interactive) and ui.has_prompt_toolkit():
        selected_gpx = ui.pick_from_paths(
            title="Select GPX file", paths=gpx_files, default_index=0, labeler=_label
        )
        if selected_gpx is None:
            return None, None

        selected_kml: Optional[Path] = None
        if kml_files:
            # KML is optional; include a None option.
            kml_choices: List[Tuple[str, str]] = [("__none__", "None (skip KML)")]
            kml_choices.extend([(str(p), _label(p)) for p in kml_files])
            picked = ui.choose_one(
                title="Select KML file (optional)",
                choices=kml_choices,
                default=kml_choices[0][0],
            )
            if picked and picked != "__none__":
                selected_kml = Path(picked)
        else:
            selected_kml = None

        return selected_gpx, selected_kml

    # Existing Rich output + Typer numeric prompts.
    console.print("\n[bold cyan]GPX files:[/]")
    for i, gpx in enumerate(gpx_files, 1):
        console.print(f"  {i}. {_label(gpx)}")

    if not kml_files:
        console.print("\n[yellow]⚠️  No KML files found (optional but recommended)[/]")
        selected_kml = None
    else:
        console.print("\n[bold cyan]KML files:[/]")
        for i, kml in enumerate(kml_files, 1):
            console.print(f"  {i}. {_label(kml)}")

    console.print()
    while True:
        try:
            gpx_choice = typer.prompt("Select GPX file number", default="1")
            selected_gpx = gpx_files[int(gpx_choice) - 1]
            break
        except (ValueError, IndexError):
            console.print("[red]Invalid selection[/] (enter a number from the list)")

    if kml_files:
        while True:
            try:
                kml_choice = typer.prompt("Select KML file number", default="1")
                selected_kml = kml_files[int(kml_choice) - 1]
                break
            except (ValueError, IndexError):
                console.print("[red]Invalid selection[/] (enter a number from the list)")
    else:
        selected_kml = None

    return selected_gpx, selected_kml


def _confirm_migration(
    gpx_path: Path,
    kml_path: Optional[Path],
    output_dir: Path,
    base_name: str,
    dedupe_waypoints: bool,
    dedupe_shapes: bool,
) -> bool:
    """
    Display migration summary and prompt for confirmation.

    Returns:
        True if user confirms, False to cancel
    """
    console.print("\n[bold]Migration Summary:[/]")
    console.print("─" * 60)

    # Input files
    console.print("\n[bold cyan]Input Files:[/]")
    console.print(f"  GPX: [green]{gpx_path.name}[/]")
    if kml_path:
        console.print(f"  KML: [green]{kml_path.name}[/]")
    else:
        console.print("  KML: [dim]None (areas may not be preserved)[/]")

    # Output files
    console.print("\n[bold cyan]Output Directory:[/]")
    console.print(f"  {_display_path(output_dir)}")

    console.print("\n[bold cyan]Output Files (will be created):[/]")
    console.print(f"  • {base_name}.json [dim](primary GeoJSON)[/]")
    console.print(f"  • {base_name}_dropped_shapes.json [dim](duplicates)[/]")
    console.print(f"  • {base_name}_trace.jsonl [dim](debug log)[/]")

    # Options
    console.print("\n[bold cyan]Processing Options:[/]")
    console.print(
        f"  Dedupe waypoints: {'[green]Yes[/]' if dedupe_waypoints else '[dim]No[/]'}"
    )
    console.print(
        f"  Dedupe shapes: {'[green]Yes[/]' if dedupe_shapes else '[dim]No[/]'}"
    )

    console.print("\n" + "─" * 60)

    # Prompt for confirmation
    return typer.confirm("\nReady to generate new map?", default=True)


# Source formats accepted by the CalTopo -> OnX direction. GPX carries only
# coordinates and names (no icons, colors, folders, or descriptions), which is
# exactly why Cairn's editing step matters most for GPX input — see README.
CALTOPO_SOURCE_EXTS = (".json", ".geojson", ".gpx")


def _describe_source_exts() -> str:
    """Human-readable list of accepted extensions, for error messages."""
    return ", ".join(CALTOPO_SOURCE_EXTS)


def _find_geojson_files(directory: Path) -> List[Path]:
    """
    Find CalTopo source files in directory.

    Returns:
        List of .json, .geojson and .gpx files. Lossless formats (.json,
        .geojson) sort before lossy .gpx, alphabetically within each group,
        so the picker's default selection never silently prefers a GPX
        (no icons/colors/folders) over a GeoJSON export of the same map.
    """
    json_files: List[Path] = []
    for ext in CALTOPO_SOURCE_EXTS:
        json_files.extend(directory.glob(f"*{ext}"))
    json_files.sort(key=lambda p: (p.suffix.lower() == ".gpx", p.name.lower()))
    return json_files


def _select_geojson_interactive(
    json_files: List[Path], *, force_interactive: Optional[bool] = None
) -> Optional[Path]:
    """
    Display available GeoJSON files and prompt user to select.

    Returns:
        Selected Path or None if cancelled
    """
    console.print("\n[bold]Found CalTopo export files:[/]")

    if not json_files:
        console.print(f"[red]No {_describe_source_exts()} files found[/]")
        return None

    def _label(p: Path) -> str:
        try:
            size = p.stat().st_size
            mtime = datetime.fromtimestamp(p.stat().st_mtime)
            return f"{p.name} ({format_file_size(size)}, {mtime:%Y-%m-%d %H:%M})"
        except Exception:
            return p.name

    if is_interactive_tty(force=force_interactive) and ui.has_prompt_toolkit():
        return ui.pick_from_paths(
            title="Select CalTopo export", paths=json_files, default_index=0, labeler=_label
        )

    console.print("\n[bold cyan]Available files:[/]")
    for i, json_file in enumerate(json_files, 1):
        console.print(f"  {i}. {_label(json_file)}")

    console.print()
    while True:
        try:
            choice = typer.prompt("Select file number", default="1")
            selected_file = json_files[int(choice) - 1]
            return selected_file
        except (ValueError, IndexError):
            console.print("[red]Invalid selection[/] (enter a number from the list)")


def _validate_geojson_file(file_path: Path) -> Tuple[bool, Optional["ParsedData"]]:
    """
    Validate a CalTopo source file (.json/.geojson/.gpx) and parse it.

    Returns:
        Tuple of (success: bool, parsed_data: Optional[ParsedData])
    """
    from cairn.core.parser import parse_geojson
    from cairn.io.caltopo_gpx import parse_caltopo_gpx

    # Check extension
    suffix = file_path.suffix.lower()
    if suffix not in CALTOPO_SOURCE_EXTS:
        console.print(
            f"[red]Expected one of {_describe_source_exts()}: {file_path}[/]"
        )
        return False, None

    # Try to parse. GPX and GeoJSON both normalize to ParsedData, so everything
    # downstream is format-agnostic from here.
    is_gpx = suffix == ".gpx"
    try:
        parsed_data = (
            parse_caltopo_gpx(file_path) if is_gpx else parse_geojson(file_path)
        )
    except Exception as e:
        console.print(
            f"[bold red]❌ Error parsing {'GPX' if is_gpx else 'GeoJSON'}:[/]"
        )
        console.print(f"[red]{e}[/]")
        return False, None

    if is_gpx:
        # GPX cannot carry icons, colors, or folders. Say so up front rather than
        # letting the user discover it after import.
        console.print(
            "[yellow]Note:[/] GPX carries only coordinates and names — no icons, "
            "colors, or folder structure.\n"
            "      Use the editing steps to add them, or re-export from CalTopo "
            "as GeoJSON for full fidelity."
        )
    return True, parsed_data


# Canonical name is lowercase `onx` (CLI-friendly).
@app.command("OnX-to-caltopo", hidden=True, deprecated=True)
@app.command("onx-to-caltopo")
def onx_to_caltopo(
    input_dir: Optional[Path] = typer.Argument(
        None,
        help="Directory containing OnX GPX and KML exports",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        "-o",
        help="Output directory (defaults to <input-dir>/caltopo_ready)",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name",
        help="Base filename (without extension) for outputs. Defaults to GPX stem.",
    ),
    dedupe_waypoints: bool = typer.Option(
        True,
        "--dedupe-waypoints/--no-dedupe-waypoints",
        help="Remove duplicate waypoints with same name and location",
    ),
    dedupe_shapes: bool = typer.Option(
        True,
        "--dedupe-shapes/--no-dedupe-shapes",
        help="Remove duplicate shapes (lines/polygons) with identical geometry",
    ),
    trace: bool = typer.Option(
        True,
        "--trace/--no-trace",
        help="Write JSONL trace log for debugging (default: enabled)",
    ),
    trace_path: Optional[Path] = typer.Option(
        None,
        "--trace-path",
        help="Custom path for trace log (overrides default location)",
    ),
    description_mode: str = typer.Option(
        "notes-only",
        "--description-mode",
        help="CalTopo description content: notes-only (default) or debug",
    ),
    route_color_strategy: str = typer.Option(
        "palette",
        "--route-color-strategy",
        help="Route stroke color when OnX line color is missing: palette (default), default-blue, or none",
    ),
):
    """Migrate OnX Backcountry exports to CalTopo GeoJSON format.

    Interactive workflow to select files, review, and confirm.
    Removes duplicate waypoints and shapes automatically.

    \b
    Examples:
      cairn migrate onx-to-caltopo
      cairn migrate onx-to-caltopo ~/Downloads/OnX-exports
      cairn migrate onx-to-caltopo ~/Downloads/OnX-exports -o ./output

    \b
    Input: Directory with GPX (waypoints) and KML (polygons).
    Output: <name>.json for CalTopo import, plus dedup reports.

    \b
    Use --no-dedupe-waypoints or --no-dedupe-shapes to keep duplicates.
    """
    import sys

    def _interactive() -> bool:
        return is_interactive_tty()

    def _prompt_resume_or_abort(*, label: str = "Resume selection or abort?") -> str:
        while True:
            raw = typer.prompt(label, default="resume").strip().lower()
            if raw in ("resume", "r"):
                return "resume"
            if raw in ("abort", "a"):
                return "abort"
            console.print("[red]Please enter 'resume' or 'abort'[/]")

    # 1. Validate input directory
    if input_dir is None:
        while True:
            if _interactive():
                picked = ui.pick_directory(title="OnX exports directory")
                if picked is None:
                    console.print("[yellow]Migration cancelled[/]")
                    raise typer.Exit(0)
                p = picked
            else:
                input_dir_str = typer.prompt("Path to directory with OnX exports")
                p = Path(input_dir_str).expanduser().resolve()
            if not p.exists() or not p.is_dir():
                console.print(f"[red]Directory not found: {p}[/]")
                continue
            gpx_files, kml_files = _find_export_files(p)
            if not gpx_files:
                console.print(f"[red]No .gpx files found in: {p}[/]")
                continue
            input_dir = p
            break
    else:
        input_dir = input_dir.expanduser().resolve()
        if not input_dir.exists() or not input_dir.is_dir():
            console.print(f"[red]Directory not found: {input_dir}[/]")
            raise typer.Exit(1)
        gpx_files, kml_files = _find_export_files(input_dir)
        if not gpx_files:
            console.print(f"[red]No .gpx files found in: {input_dir}[/]")
            raise typer.Exit(1)

    # 3. Determine output directory (stable across resumes)
    if output_dir is None:
        output_dir = input_dir / "caltopo_ready"

    out_dir = ensure_output_dir(output_dir)
    # 4. Interactive file selection + final gate
    while True:
        gpx, kml = _select_files_interactive(
            gpx_files, kml_files, force_interactive=_interactive()
        )
        if gpx is None:
            console.print("[yellow]Migration cancelled[/]")
            raise typer.Exit(0)

        base = (name or gpx.stem).strip() or gpx.stem

        if _confirm_migration(gpx, kml, out_dir, base, dedupe_waypoints, dedupe_shapes):
            break

        if not _interactive():
            console.print("[yellow]Migration cancelled[/]")
            raise typer.Exit(0)

        action = _prompt_resume_or_abort()
        if action == "abort":
            console.print("[yellow]Migration cancelled[/]")
            raise typer.Exit(0)

    _run_onx_to_caltopo_pipeline(
        gpx=gpx,
        kml=kml,
        out_dir=out_dir,
        base=base,
        dedupe_waypoints=dedupe_waypoints,
        dedupe_shapes=dedupe_shapes,
        trace=trace,
        trace_path=trace_path,
        description_mode=description_mode,
        route_color_strategy=route_color_strategy,
    )


@app.command("caltopo")
def migrate_to_caltopo(
    source: Optional[Path] = typer.Argument(
        None,
        help="OnX export input: a directory, a .gpx file, or a .kml file (GPX required; KML optional)",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        "-o",
        help="Output directory (defaults to <input-dir>/caltopo_ready)",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name",
        help="Base filename (without extension) for outputs. Defaults to GPX stem.",
    ),
    dedupe_waypoints: bool = typer.Option(
        True,
        "--dedupe-waypoints/--no-dedupe-waypoints",
        help="Remove duplicate waypoints with same name and location",
    ),
    dedupe_shapes: bool = typer.Option(
        True,
        "--dedupe-shapes/--no-dedupe-shapes",
        help="Remove duplicate shapes (lines/polygons) with identical geometry",
    ),
    trace: bool = typer.Option(
        True,
        "--trace/--no-trace",
        help="Write JSONL trace log for debugging (default: enabled)",
    ),
    trace_path: Optional[Path] = typer.Option(
        None,
        "--trace-path",
        help="Custom path for trace log (overrides default location)",
    ),
    description_mode: str = typer.Option(
        "notes-only",
        "--description-mode",
        help="CalTopo description content: notes-only (default) or debug",
    ),
    route_color_strategy: str = typer.Option(
        "palette",
        "--route-color-strategy",
        help="Route stroke color when OnX line color is missing: palette (default), default-blue, or none",
    ),
):
    """
    Alias for `migrate onx-to-caltopo` (target is CalTopo).

    Supports passing a directory or a specific .gpx file (and optional matching .kml).
    """
    import sys

    def _interactive() -> bool:
        return is_interactive_tty()

    src = _as_existing_path(source)
    preferred_gpx: Optional[Path] = None
    preferred_kml: Optional[Path] = None

    if src is not None and src.is_file():
        if src.suffix.lower() == ".gpx":
            preferred_gpx = src
        elif src.suffix.lower() == ".kml":
            preferred_kml = src
        else:
            console.print(
                f"[red]Unsupported input file type:[/] {src.name} (expected .gpx or .kml)"
            )
            raise typer.Exit(1)
        input_dir = src.parent
    elif src is not None and src.is_dir():
        input_dir = src
    else:
        # Prompt for directory (reprompt on invalid).
        if source is not None:
            console.print(f"[red]Path not found:[/] {source}")
            if not _interactive():
                raise typer.Exit(1)
        if not _interactive():
            raise typer.Exit(1)
        while True:
            picked = ui.pick_directory(title="OnX exports directory")
            if picked is None:
                console.print("[yellow]Migration cancelled[/]")
                raise typer.Exit(0)
            p = picked
            if not p.exists() or not p.is_dir():
                console.print(f"[red]Directory not found: {p}[/]")
                continue
            input_dir = p
            break

    gpx_files, kml_files = _find_export_files(input_dir)
    if not gpx_files:
        console.print(f"[red]No .gpx files found in: {input_dir}[/]")
        if _interactive():
            raise typer.Exit(1)
        raise typer.Exit(1)

    # Prefer the explicitly provided file first so Enter selects it.
    gpx_files = _reorder_prefer_first(gpx_files, preferred_gpx)
    kml_files = _reorder_prefer_first(kml_files, preferred_kml)

    gpx, kml = _select_files_interactive(
        gpx_files, kml_files, force_interactive=_interactive()
    )
    if gpx is None:
        console.print("[yellow]Migration cancelled[/]")
        raise typer.Exit(0)

    # If user gave a GPX file, auto-use same-stem KML if present and no KML was selected.
    if preferred_gpx is not None and kml is None:
        candidate = preferred_gpx.with_suffix(".kml")
        if candidate.exists():
            kml = candidate

    if output_dir is None:
        output_dir = input_dir / "caltopo_ready"
    out_dir = ensure_output_dir(output_dir)

    base = (name or gpx.stem).strip() or gpx.stem
    if not _confirm_migration(gpx, kml, out_dir, base, dedupe_waypoints, dedupe_shapes):
        console.print("[yellow]Migration cancelled[/]")
        raise typer.Exit(0)

    _run_onx_to_caltopo_pipeline(
        gpx=gpx,
        kml=kml,
        out_dir=out_dir,
        base=base,
        dedupe_waypoints=dedupe_waypoints,
        dedupe_shapes=dedupe_shapes,
        trace=trace,
        trace_path=trace_path,
        description_mode=description_mode,
        route_color_strategy=route_color_strategy,
    )


# Canonical name is lowercase `onx` (CLI-friendly).
@app.command("caltopo-to-OnX", hidden=True, deprecated=True)
@app.command("caltopo-to-onx")
def caltopo_to_onx(
    input_dir: Optional[Path] = typer.Argument(
        None,
        help="CalTopo input: directory containing exports, or a single .json/.geojson/.gpx file",
        exists=True,
        file_okay=True,
        dir_okay=True,
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        "-o",
        help="Output directory (defaults to <input-dir>/onx_ready)",
    ),
    config_file: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        help="Custom icon mapping configuration file",
    ),
    no_sort: bool = typer.Option(
        False,
        "--no-sort",
        help="Preserve original order instead of natural sorting",
    ),
    max_gpx_mb: float = typer.Option(
        3.75,
        "--max-gpx-mb",
        help="Maximum GPX file size in MB before auto-splitting (OnX import limit is 4MB; default keeps a safety margin).",
    ),
    split_gpx: bool = typer.Option(
        True,
        "--split-gpx/--no-split-gpx",
        help="Automatically split GPX files that exceed the max size into multiple numbered parts.",
    ),
    session_file: Optional[Path] = typer.Option(
        None,
        "--session",
        help="Path to an edit-session JSON file to auto-load/auto-save interactive edits (default: <output_dir>/<input>_session.json).",
    ),
    save_session: bool = typer.Option(
        True,
        "--save-session/--no-save-session",
        help="Auto-save interactive edits to the session file so you can resume after reruns (default: enabled).",
    ),
    interactive: Optional[bool] = typer.Option(
        None,
        "--interactive/--no-interactive",
        help="Force interactive prompting even when stdin is not a TTY (useful for scripted testing). Default: auto-detect.",
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Include Cairn's internal key=value block (name/id/color/icon/...) in each GPX <desc> for troubleshooting. Default: <desc> carries only your own notes.",
    ),
):
    """Migrate CalTopo GeoJSON exports to OnX-importable GPX/KML format.

    Interactive workflow to select file, validate, review, and confirm.
    Maps CalTopo symbols to OnX icons and preserves colors/styles.

    \b
    Examples:
      cairn migrate caltopo-to-onx
      cairn migrate caltopo-to-onx ~/Downloads/caltopo-exports
      cairn migrate caltopo-to-onx ~/Downloads/caltopo-exports -o ./output

    \b
    Input: Directory with CalTopo GeoJSON export file(s).
    Output: GPX files (waypoints/tracks) and KML files (polygons).

    \b
    Use --no-sort to preserve original order instead of natural sorting.

    \b
    Tip: When you use interactive editing, Cairn can auto-save your edits to a session file
    (see --session / --save-session). Re-run the command to resume without losing work.
    """
    from cairn.commands.convert_cmd import (
        display_name_sanitization_warnings,
        collect_unmapped_caltopo_symbols,
        display_unmapped_symbols,
        handle_unmapped_symbols,
        process_and_write_files,
    )
    from cairn.core.config import load_config
    from cairn.core.preview import (
        preview_sorted_order,
        interactive_edit_before_export_per_folder,
    )
    from cairn.core.edit_session import (
        init_or_load_session,
        save_session as persist_session,
    )
    from rich.prompt import Confirm
    from cairn.utils.utils import natural_sort_key
    import sys

    def _interactive() -> bool:
        if interactive is not None:
            return bool(interactive)
        return is_interactive_tty()

    def _print_folder_previews() -> None:
        console.print("\n[bold]Migration Summary:[/]")
        console.print("[dim]Per-folder order as it will be written for OnX.[/]\n")

        folder_items = list((getattr(parsed_data, "folders", {}) or {}).items())
        folder_items.sort(
            key=lambda kv: natural_sort_key(str((kv[1] or {}).get("name") or kv[0]))
        )
        for _, folder_data in folder_items:
            folder_name = str(folder_data.get("name") or "")
            tracks = list(folder_data.get("tracks", []) or [])
            waypoints = list(folder_data.get("waypoints", []) or [])
            if sort_enabled:
                tracks = sorted(tracks, key=lambda f: natural_sort_key(f.title))
                waypoints = sorted(waypoints, key=lambda f: natural_sort_key(f.title))

            if tracks:
                preview_sorted_order(
                    tracks, "tracks", folder_name, skip_confirmation=True, config=None
                )
            if waypoints:
                preview_sorted_order(
                    waypoints,
                    "waypoints",
                    folder_name,
                    skip_confirmation=True,
                    config=config,
                )

    def _prompt_resume_or_abort(*, label: str = "Resume editing or abort?") -> str:
        while True:
            raw = typer.prompt(label, default="resume").strip().lower()
            if raw in ("resume", "r"):
                return "resume"
            if raw in ("abort", "a"):
                return "abort"
            console.print("[red]Please enter 'resume' or 'abort'[/]")

    # 1. Validate input (directory or file)
    selected_file: Optional[Path] = None
    json_files: List[Path] = []

    if input_dir is None:
        while True:
            if _interactive():
                picked = ui.pick_directory(title="CalTopo exports directory")
                if picked is None:
                    console.print("[yellow]Migration cancelled[/]")
                    raise typer.Exit(0)
                p = picked
            else:
                input_dir_str = typer.prompt("Path to directory with CalTopo exports")
                p = Path(input_dir_str).expanduser().resolve()
            if not p.exists() or not p.is_dir():
                console.print(f"[red]Directory not found: {p}[/]")
                continue
            json_files = _find_geojson_files(p)
            if not json_files:
                console.print(
                    f"[red]No {_describe_source_exts()} files found in: {p}[/]"
                )
                continue
            input_dir = p
            break
    else:
        input_dir = input_dir.expanduser().resolve()
        if not input_dir.exists():
            console.print(f"[red]Path not found: {input_dir}[/]")
            raise typer.Exit(1)
        if input_dir.is_file():
            if input_dir.suffix.lower() not in CALTOPO_SOURCE_EXTS:
                console.print(
                    f"[red]Expected one of {_describe_source_exts()}: {input_dir}[/]"
                )
                raise typer.Exit(1)
            selected_file = input_dir
            input_dir = input_dir.parent
        else:
            if not input_dir.is_dir():
                console.print(f"[red]Directory not found: {input_dir}[/]")
                raise typer.Exit(1)
            json_files = _find_geojson_files(input_dir)
            if not json_files:
                console.print(
                    f"[red]No {_describe_source_exts()} files found in: {input_dir}[/]"
                )
                raise typer.Exit(1)

    # 3. Interactive file selection
    if selected_file is None:
        selected_file = _select_geojson_interactive(
            json_files, force_interactive=_interactive()
        )
        if selected_file is None:
            console.print("[yellow]Migration cancelled[/]")
            raise typer.Exit(0)

    # 4. Validate selected GeoJSON
    valid, parsed_data = _validate_geojson_file(selected_file)
    if not valid or parsed_data is None:
        raise typer.Exit(1)

    # 5. Determine output directory
    if output_dir is None:
        output_dir = input_dir / "onx_ready"

    out_dir = ensure_output_dir(output_dir)

    # 6. Load icon mapping config
    config = load_config(config_file)

    # 6b. Optional: resume interactive edits from a session file (autosaved checkpoints).
    session = None
    session_path: Optional[Path] = None
    if save_session:
        session_path = (
            session_file.expanduser()
            if session_file is not None
            else (out_dir / f"{selected_file.stem}_session.json")
        )
        session = init_or_load_session(path=session_path, input_path=selected_file)
        try:
            resumed = session.apply_to_parsed_data(parsed_data)
        except Exception:
            resumed = 0
        if resumed:
            console.print(
                f"[dim]Resumed {resumed} edit(s) from session:[/] [cyan]{_display_path(session_path)}[/]"
            )
        else:
            # Keep this quiet; only tell the user where edits will be saved once we enter edit mode.
            pass

    # Show unmapped-symbol warning early so users can map symbols before export.
    unmapped_report = collect_unmapped_caltopo_symbols(parsed_data, config)
    display_unmapped_symbols(config, unmapped_report=unmapped_report)

    # Optional: allow users to persist mappings immediately, before previews/edits/exports.
    if unmapped_report and _interactive():
        if Confirm.ask(
            "Map these symbols now and save them to your config?", default=True
        ):
            mappings_added = handle_unmapped_symbols(
                config,
                unmapped_report=unmapped_report,
                interactive=True,
                config_path=(config_file or Path("cairn_config.yaml")),
            )
            if mappings_added:
                console.print(
                    "\n[green]✓[/] Reloading configuration with new mappings...\n"
                )
                config = load_config(config_file)
                unmapped_report = collect_unmapped_caltopo_symbols(parsed_data, config)
                display_unmapped_symbols(config, unmapped_report=unmapped_report)

    # 7. Preview (and optional edit) before final confirmation
    sort_enabled = not no_sort

    _print_folder_previews()

    # Optional edit step (interactive terminals only).
    if _interactive():
        if Confirm.ask("Would you like to edit anything before export?", default=False):
            if save_session and session_path is not None:
                console.print(
                    f"[dim]Edits will be auto-saved to:[/] [cyan]{_display_path(session_path)}[/]"
                )
            interactive_edit_before_export_per_folder(
                parsed_data,
                config,
                sort_enabled=sort_enabled,
                session=session,
                session_path=session_path,
                autosave_session=save_session,
            )
            console.print("\n[dim]Updated order after edits:[/]")
            _print_folder_previews()

    # 8. Final gate: Ready to generate new map?
    while True:
        if typer.confirm("\nReady to generate new map?", default=True):
            break
        if not _interactive():
            console.print("[yellow]Migration cancelled[/]")
            raise typer.Exit(0)
        action = _prompt_resume_or_abort()
        if action == "abort":
            console.print("[yellow]Migration cancelled[/]")
            raise typer.Exit(0)
        if save_session and session_path is not None:
            console.print(
                f"[dim]Edits will be auto-saved to:[/] [cyan]{_display_path(session_path)}[/]"
            )
        interactive_edit_before_export_per_folder(
            parsed_data,
            config,
            sort_enabled=sort_enabled,
            session=session,
            session_path=session_path,
            autosave_session=save_session,
        )
        console.print("\n[dim]Updated order after edits:[/]")
        _print_folder_previews()

    # 9. Process and write files
    console.print("\n[bold white]Processing...[/]\n")

    # Icon report + catalog for CalTopo → OnX (best-effort; never fails the migration)
    try:
        registry = IconRegistry()
        inventory = registry.collect_caltopo_symbol_inventory(parsed_data)
        rows = registry.collect_caltopo_to_onx_mapping_rows_using_config(
            parsed_data, config
        )

        # Append to repo catalog (policy: append catalog only; no auto-mapping)
        registry.append_symbol_inventory_to_catalog(inventory)

        icon_report_path = out_dir / f"{selected_file.stem}_ICON_REPORT.md"
        write_icon_report_markdown(
            output_path=icon_report_path,
            title="CalTopo → OnX icon report",
            inventories=inventory,
            rows=rows,
            notes=(
                f"Input GeoJSON: `{selected_file.name}`",
                *(tuple([f"Config: `{config_file}`"]) if config_file else ()),
                f"Mappings source: `{registry.mappings_path}` (conversion uses runtime config, including user overrides)",
                f"Catalog updated: `{registry.catalog_path}`",
            ),
        )
    except Exception:
        # Migration should still succeed even if reporting fails.
        pass

    output_files = process_and_write_files(
        parsed_data,
        out_dir,
        sort=sort_enabled,
        skip_confirmation=True,  # Already confirmed
        config=config,
        split_gpx=split_gpx,
        max_gpx_bytes=int(max(0.0, float(max_gpx_mb)) * 1024 * 1024),
        debug_desc=debug,
    )

    # Persist session one last time (best-effort) so users can resume even if export artifacts change later.
    if save_session and session is not None and session_path is not None:
        try:
            persist_session(session_path, session)
        except Exception:
            pass

    # 10. Display results
    if not output_files:
        console.print("[yellow]No files were created[/]")
        raise typer.Exit(1)

    # Display name sanitization warnings
    display_name_sanitization_warnings()

    # Success footer
    console.print(
        f"\n[bold green]✔ SUCCESS[/] Data written to [underline]{out_dir}[/]\n"
    )


@app.command("onx")
def migrate_to_onx(
    source: Optional[Path] = typer.Argument(
        None,
        help="CalTopo input: a directory or a single .json/.geojson/.gpx file",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        "-o",
        help="Output directory (defaults to <input-dir>/onx_ready)",
    ),
    config_file: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        help="Custom icon mapping configuration file",
    ),
    no_sort: bool = typer.Option(
        False,
        "--no-sort",
        help="Preserve original order instead of natural sorting",
    ),
    max_gpx_mb: float = typer.Option(
        3.75,
        "--max-gpx-mb",
        help="Maximum GPX file size in MB before auto-splitting (OnX import limit is 4MB; default keeps a safety margin).",
    ),
    split_gpx: bool = typer.Option(
        True,
        "--split-gpx/--no-split-gpx",
        help="Automatically split GPX files that exceed the max size into multiple numbered parts.",
    ),
    session_file: Optional[Path] = typer.Option(
        None,
        "--session",
        help="Path to an edit-session JSON file to auto-load/auto-save interactive edits (default: <output_dir>/<input>_session.json).",
    ),
    save_session: bool = typer.Option(
        True,
        "--save-session/--no-save-session",
        help="Auto-save interactive edits to the session file so you can resume after reruns (default: enabled).",
    ),
    interactive: Optional[bool] = typer.Option(
        None,
        "--interactive/--no-interactive",
        help="Force interactive prompting even when stdin is not a TTY (useful for scripted testing). Default: auto-detect.",
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Include Cairn's internal key=value block (name/id/color/icon/...) in each GPX <desc> for troubleshooting. Default: <desc> carries only your own notes.",
    ),
):
    """
    Alias for `migrate caltopo-to-onx` (target is OnX).

    Supports passing a directory or a specific GeoJSON file.
    """
    return caltopo_to_onx(
        input_dir=source,
        output_dir=output_dir,
        config_file=config_file,
        no_sort=no_sort,
        max_gpx_mb=max_gpx_mb,
        split_gpx=split_gpx,
        session_file=session_file,
        save_session=save_session,
        interactive=interactive,
        debug=debug,
    )
