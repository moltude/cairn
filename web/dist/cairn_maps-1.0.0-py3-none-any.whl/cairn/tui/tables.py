"""Table operations for the TUI module.

This module manages DataTable operations extracted from app.py for better
testability and separation of concerns.
"""

from typing import Optional, TYPE_CHECKING, Any
from textual.coordinate import Coordinate
from textual.widgets import DataTable, Input
from rich.text import Text

from cairn.core.color_mapper import ColorMapper
from cairn.core.mapper import map_icon
from cairn.core.config import get_icon_color

if TYPE_CHECKING:
    from cairn.tui.app import CairnTuiApp

# Import profiling
try:
    from cairn.tui.profiling import profile_operation
except ImportError:
    # Fallback if profiling module not available
    from contextlib import nullcontext as profile_operation


class TableManager:
    """Manages DataTable operations for the TUI."""

    def __init__(self, app: "CairnTuiApp") -> None:
        """Initialize table manager.

        Args:
            app: The CairnTuiApp instance (for accessing model, config, etc.)
        """
        self.app: "CairnTuiApp" = app

    @staticmethod
    def cursor_row_key(table: DataTable) -> Optional[str]:
        """Get row key at cursor position.

        Best-effort current row key at cursor for version-compat.

        Args:
            table: The DataTable to query

        Returns:
            Row key as string, or None if not available
        """
        try:
            coord = getattr(table, "cursor_coordinate", None)
            if coord is not None and hasattr(table, "coordinate_to_cell_key"):
                cell_key = table.coordinate_to_cell_key(coord)
                rk = getattr(cell_key, "row_key", None)
                if rk is not None:
                    return str(getattr(rk, "value", rk))
        except Exception:
            pass
        try:
            row_idx = getattr(table, "cursor_row", None)
            if row_idx is not None and hasattr(table, "get_row_key"):
                rk = table.get_row_key(row_idx)
                if rk is not None:
                    return str(getattr(rk, "value", rk))
        except Exception:
            # Textual API version compatibility - fallback if cursor methods don't exist
            pass
        return None

    @staticmethod
    def clear_rows(table: DataTable) -> None:
        """Clear all rows from a DataTable.

        Clear rows without forcing a full screen re-render.
        Textual DataTable APIs vary; we try common variants.

        Args:
            table: The DataTable to clear
        """
        # Try newer API: clear(columns=False)
        try:
            table.clear(columns=False)  # type: ignore[call-arg]
            return
        except TypeError:
            pass
        except Exception:
            # fall through
            pass

        # Try clear() (may clear columns too)
        try:
            table.clear()  # type: ignore[call-arg]
            return
        except Exception:
            pass

        # Fallback: best-effort remove rows if supported
        try:
            row_keys = list(getattr(table, "rows", {}).keys())  # type: ignore[attr-defined]
            for rk in row_keys:
                table.remove_row(rk)  # type: ignore[call-arg]
        except Exception:
            return

    def color_chip(self, rgba: str) -> Text:
        """Create a color chip widget for display in tables.

        Args:
            rgba: RGBA color string

        Returns:
            Rich Text object with color chip
        """
        r, g, b = ColorMapper.parse_color(rgba)
        name = ColorMapper.get_color_name(rgba).replace("-", " ").upper()
        chip = Text("■ ", style=f"rgb({r},{g},{b})")
        chip.append(name, style="bold")
        return chip

    def resolved_waypoint_icon(self, wp: Any) -> str:
        """Resolve the OnX icon for a waypoint.

        Checks for override in properties, otherwise uses mapping logic.

        Args:
            wp: Waypoint feature object (ParsedFeature or similar)

        Returns:
            Icon name string
        """
        try:
            props = getattr(wp, "properties", None)
            if isinstance(props, dict):
                ov = (props.get("cairn_onx_icon_override") or "").strip()
                if ov:
                    return ov
        except Exception:
            pass
        title0 = str(getattr(wp, "title", "") or "")
        desc0 = str(getattr(wp, "description", "") or "")
        sym0 = str(getattr(wp, "symbol", "") or "")
        return map_icon(title0, desc0, sym0, self.app._config)

    def resolved_waypoint_color(self, wp: Any, icon: str) -> str:
        """Resolve the OnX color for a waypoint.

        Mirrors cairn/core/writers.py policy.

        Args:
            wp: Waypoint feature object (ParsedFeature or similar)
            icon: Icon name (used for default color lookup)

        Returns:
            RGBA color string
        """
        # Mirror cairn/core/writers.py policy.
        mc_raw = str(getattr(wp, "color", "") or "").strip()
        if mc_raw:
            return ColorMapper.map_waypoint_color(mc_raw)
        return get_icon_color(
            icon,
            default=getattr(self.app._config, "default_color", ColorMapper.DEFAULT_WAYPOINT_COLOR),
        )

    def _feature_row_key(self, feat: Any, index: str) -> str:
        """Generate a stable row key for a feature.

        Creates a unique key for table row identification.

        Args:
            feat: Feature object (route or waypoint, ParsedFeature or similar)
            index: Index string (for uniqueness)

        Returns:
            Row key string
        """
        # Try to use a stable ID if available
        try:
            feat_id = getattr(feat, "id", None)
            if feat_id:
                return str(feat_id)
        except Exception:
            pass

        # Fallback to index-based key
        # Use title + index for uniqueness
        try:
            title = str(getattr(feat, "title", "") or "Untitled")
            return f"{title}_{index}"
        except Exception:
            return f"feature_{index}"

    def _get_overlay_selectors(self) -> tuple[str, ...]:
        """Return tuple of overlay selectors that should prevent cursor restoration."""
        return (
            "#inline_edit_overlay",
            "#rename_overlay",
            "#description_overlay",
            "#color_picker_overlay",
            "#icon_picker_overlay",
            "#confirm_overlay",
            "#save_target_overlay",
        )

    def _is_overlay_open(self) -> bool:
        """Check if any overlay is currently open."""
        try:
            return any(
                self.app._overlay_open(sel)
                for sel in self._get_overlay_selectors()
            )
        except Exception:
            return False

    def _find_row_index_by_key(self, table: DataTable, row_key: str, row_count: int) -> Optional[int]:
        """Find row index by row key in the table."""
        try:
            if hasattr(table, "get_row_key"):
                for i in range(row_count):
                    try:
                        rk = table.get_row_key(i)  # type: ignore[attr-defined]
                        rk_val = str(getattr(rk, "value", rk))
                        if rk_val == str(row_key):
                            return i
                    except Exception:
                        continue
        except Exception:
            pass
        return None

    def _move_cursor_to_index(self, table: DataTable, target_idx: int) -> None:
        """Move cursor directly to the specified row index.

        Sets the cursor coordinate in O(1) instead of simulating per-row
        cursor_up/cursor_down actions, which is quadratic on large tables
        (~12,000 widget actions to restore row 6000 of 10,000).
        """
        try:
            col = int(getattr(table, "cursor_column", 0) or 0)
        except Exception:
            col = 0
        try:
            table.cursor_coordinate = Coordinate(int(target_idx), col)
            return
        except Exception:
            pass
        # Fallback for Textual versions where the reactive assignment fails.
        try:
            table.move_cursor(row=int(target_idx), column=col)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _restore_cursor_after_refresh(
        self,
        table: DataTable,
        *,
        desired_row_key: Optional[str],
        desired_index_fallback: Optional[int],
        timer_name: str,
    ) -> None:
        """
        Best-effort restore cursor position after a table refresh.

        We prefer restoring by row key (stable across sorting / filtering). If that
        isn't available or isn't visible after filtering, we fall back to the prior
        cursor index (clamped).
        """

        def _restore() -> None:
            try:
                # Never steal focus away from an in-screen overlay.
                if self._is_overlay_open():
                    return

                table_refreshed = table
                # Don't steal focus while the user is typing in an Input
                # (e.g. the '/' search box triggers a refresh on every
                # keystroke; focusing the table here would eat the search
                # box's focus after one character). Still restore the
                # cursor position below either way.
                focused = getattr(self.app, "focused", None)
                if not isinstance(focused, Input):
                    try:
                        table_refreshed.focus()
                    except Exception:
                        pass

                row_count = int(getattr(table_refreshed, "row_count", 0) or 0)
                if row_count <= 0:
                    return

                target_idx: Optional[int] = None

                if desired_row_key:
                    target_idx = self._find_row_index_by_key(table_refreshed, desired_row_key, row_count)

                if target_idx is None and desired_index_fallback is not None:
                    try:
                        target_idx = min(max(int(desired_index_fallback), 0), row_count - 1)
                    except Exception:
                        target_idx = None

                if target_idx is None:
                    return

                self._move_cursor_to_index(table_refreshed, target_idx)
            except Exception:
                return

        # Schedule the restore exactly once, after the refresh has been
        # painted. (A second set_timer fallback used to run the whole restore
        # again 50ms later, doubling the cost of every refresh.)
        del timer_name  # kept in the signature for call-site compatibility
        try:
            self.app.call_after_refresh(_restore)
        except Exception:
            _restore()

    def refresh_folder_table(self) -> Optional[int]:
        """Refresh the folder table to show updated selection state.

        Returns the target cursor row index if a row key was saved, None otherwise.
        """
        with profile_operation("table_refresh_folder"):
            if self.app.step != "Folder":
                return None
            try:
                table = self.app.query_one("#folder_table", DataTable)
            except Exception:
                return None
            if self.app.model.parsed is None:
                return None

            folders = list((getattr(self.app.model.parsed, "folders", {}) or {}).items())
            if not folders:
                return None

            # Save current cursor position by row key (more reliable than row index)
            current_row_key = None
            try:
                current_row_key = self.cursor_row_key(table)
            except Exception:
                pass
            try:
                current_row_idx = int(getattr(table, "cursor_row", 0) or 0)
            except Exception:
                current_row_idx = None

            # Clear rows
            self.clear_rows(table)

            # Ensure columns exist
            try:
                if not getattr(table, "columns", None):  # type: ignore[attr-defined]
                    if len(folders) > 1:
                        table.add_columns("Selected", "Folder", "Waypoints", "Routes", "Shapes")
                    else:
                        table.add_columns("Folder", "Waypoints", "Routes", "Shapes")
            except Exception:
                try:
                    if len(folders) > 1:
                        table.add_columns("Selected", "Folder", "Waypoints", "Routes", "Shapes")
                    else:
                        table.add_columns("Folder", "Waypoints", "Routes", "Shapes")
                except Exception:
                    pass

            # Sort folders alphabetically
            folders = sorted(folders, key=lambda x: str((x[1] or {}).get("name") or x[0]).lower())

            # Re-add rows with updated selection state
            target_row_index = None
            for idx, (folder_id, fd) in enumerate(folders):
                name = str((fd or {}).get("name") or folder_id)
                w = len((fd or {}).get("waypoints", []) or [])
                t = len((fd or {}).get("tracks", []) or [])
                s = len((fd or {}).get("shapes", []) or [])
                if len(folders) > 1:
                    sel = "●" if folder_id in self.app._selected_folders else " "
                    table.add_row(sel, name, str(w), str(t), str(s), key=folder_id)
                else:
                    table.add_row(name, str(w), str(t), str(s), key=folder_id)

                # Track the index of the row we want to restore cursor to
                if current_row_key and str(folder_id) == str(current_row_key):
                    target_row_index = idx

            # Restore cursor to the same folder row after refresh.
            self._restore_cursor_after_refresh(
                table,
                desired_row_key=str(current_row_key) if current_row_key else None,
                desired_index_fallback=current_row_idx,
                timer_name="restore_folder_cursor",
            )

            # Return target index for caller to restore cursor
            return target_row_index if current_row_key and target_row_index is not None else None

    def refresh_waypoints_table(self) -> None:
        """Refresh the waypoints table with current data and filters."""
        with profile_operation("table_refresh_waypoints"):
            if self.app.step != "Waypoints":
                return
            try:
                table = self.app.query_one("#waypoints_table", DataTable)
            except Exception:
                return
            if self.app.model.parsed is None or not self.app.model.selected_folder_id:
                return
            fd = (getattr(self.app.model.parsed, "folders", {}) or {}).get(self.app.model.selected_folder_id)
            waypoints = list((fd or {}).get("waypoints", []) or [])

            q = (self.app._waypoints_filter or "").strip().lower()
            # Capture cursor before clearing rows.
            try:
                current_row_key = self.cursor_row_key(table)
            except Exception:
                current_row_key = None
            try:
                current_row_idx = int(getattr(table, "cursor_row", 0) or 0)
            except Exception:
                current_row_idx = None
            self.clear_rows(table)

            # Ensure columns exist if clear() nuked them.
            try:
                if not getattr(table, "columns", None):  # type: ignore[attr-defined]
                    table.add_columns("Selected", "Name", "OnX icon", "OnX color")
            except Exception:
                try:
                    table.add_columns("Selected", "Name", "OnX icon", "OnX color")
                except Exception:
                    pass

            # Sort waypoints alphabetically by name (case-insensitive)
            waypoints = sorted(waypoints, key=lambda wp: str(getattr(wp, "title", "") or "Untitled").lower())

            for i, wp in enumerate(waypoints):
                key = self._feature_row_key(wp, str(i))
                title0 = str(getattr(wp, "title", "") or "Untitled")
                if q and q not in title0.lower():
                    continue
                sel = "●" if key in self.app._selected_waypoint_keys else " "
                mapped = self.resolved_waypoint_icon(wp)
                rgba = self.resolved_waypoint_color(wp, mapped)
                try:
                    table.add_row(sel, title0, mapped, self.color_chip(rgba), key=key)
                except Exception:
                    name = ColorMapper.get_color_name(rgba).replace("-", " ").upper()
                    table.add_row(sel, title0, mapped, f"■ {name}", key=key)

            # Restore cursor to the same waypoint row after refresh.
            self._restore_cursor_after_refresh(
                table,
                desired_row_key=str(current_row_key) if current_row_key else None,
                desired_index_fallback=current_row_idx,
                timer_name="restore_waypoints_cursor",
            )

    def refresh_routes_table(self) -> None:
        """Refresh the routes table with current data and filters."""
        with profile_operation("table_refresh_routes"):
            if self.app.step != "Routes":
                return
            try:
                table = self.app.query_one("#routes_table", DataTable)
            except Exception:
                return
            if self.app.model.parsed is None or not self.app.model.selected_folder_id:
                return
            fd = (getattr(self.app.model.parsed, "folders", {}) or {}).get(self.app.model.selected_folder_id)
            tracks = list((fd or {}).get("tracks", []) or [])

            q = (self.app._routes_filter or "").strip().lower()
            # Capture cursor before clearing rows.
            try:
                current_row_key = self.cursor_row_key(table)
            except Exception:
                current_row_key = None
            try:
                current_row_idx = int(getattr(table, "cursor_row", 0) or 0)
            except Exception:
                current_row_idx = None
            self.clear_rows(table)

            try:
                if not getattr(table, "columns", None):  # type: ignore[attr-defined]
                    table.add_columns("Selected", "Name", "Color", "Pattern", "Width")
            except Exception:
                try:
                    table.add_columns("Selected", "Name", "Color", "Pattern", "Width")
                except Exception:
                    pass

            # Sort routes alphabetically by name (case-insensitive)
            tracks = sorted(tracks, key=lambda trk: str(getattr(trk, "title", "") or "Untitled").lower())

            for i, trk in enumerate(tracks):
                key = self._feature_row_key(trk, str(i))
                name = str(getattr(trk, "title", "") or "Untitled")
                if q and q not in name.lower():
                    continue
                sel = "●" if key in self.app._selected_route_keys else " "
                rgba = ColorMapper.map_track_color(str(getattr(trk, "stroke", "") or ""))
                try:
                    color_cell = self.color_chip(rgba)
                except Exception:
                    color_cell = f"■ {ColorMapper.get_color_name(rgba).replace('-', ' ').upper()}"
                table.add_row(
                    sel,
                    name,
                    color_cell,
                    str(getattr(trk, "pattern", "") or ""),
                    str(getattr(trk, "stroke_width", "") or ""),
                    key=key,
                )

            # Restore cursor to the same route row after refresh.
            self._restore_cursor_after_refresh(
                table,
                desired_row_key=str(current_row_key) if current_row_key else None,
                desired_index_fallback=current_row_idx,
                timer_name="restore_routes_cursor",
            )


__all__ = ["TableManager"]
